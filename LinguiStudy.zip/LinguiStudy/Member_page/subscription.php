<?php
session_start();
include("../index/index.php");
include("../index/navbar.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$query = mysqli_query($conn, "SELECT is_premium FROM users WHERE user_id = '$user_id'");
$user = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subscription | LinguiStudy</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/member-page/subscription.css">
</head>
<body>

<div class="sub-wrapper">
    <div class="glow-bg"></div>
    <div class="sub-header" data-aos="fade-down">
        <span class="badge-sub">Premium Access</span>
        <h1>Pilih Paket Belajar</h1>
        <p>Investasi terbaik untuk masa depan bahasa Anda</p>
    </div>

    <div class="sub-grid">
        <div class="sub-card" data-aos="fade-up" data-aos-delay="100">
            <div class="card-glass"></div>
            <div class="card-content">
                <h3>Premium Bulanan</h3>
                <div class="price">Rp 49.000 <span>/ bulan</span></div>
                <ul>
                    <li><span class="check">✓</span> Semua Kursus Terbuka</li>
                    <li><span class="check">✓</span> Materi Menengah & Mahir</li>
                    <li><span class="check">✓</span> Sertifikat Resmi</li>
                    <li><span class="check">✓</span> Latihan Interaktif</li>
                </ul>
                <form action="proses_transaksi.php" method="POST">
                    <input type="hidden" name="jenis" value="bulanan">
                    <input type="hidden" name="harga" value="49000">
                    <button type="submit" name="bayar" class="btn-buy">Pilih Bulanan</button>
                </form>
            </div>
        </div>

        <div class="sub-card premium-glow" data-aos="fade-up" data-aos-delay="200">
            <div class="card-glass featured"></div>
            <div class="best-value">Hemat 30%</div>
            <div class="card-content">
                <h3>Premium Tahunan</h3>
                <div class="price neon-text">Rp 399.000 <span>/ tahun</span></div>
                <p class="monthly-breakdown">Hanya Rp 33.250 / bulan</p>
                <ul>
                    <li><span class="check neon">✓</span> Semua Kursus Terbuka</li>
                    <li><span class="check neon">✓</span> Materi Menengah & Mahir</li>
                    <li><span class="check neon">✓</span> Sertifikat Resmi</li>
                    <li><span class="check neon">✓</span> Opsi materi yang banyak</li>
                    <li><span class="check neon">✓</span> Akses Offline Materi</li>
                </ul>
                <form action="proses_transaksi.php" method="POST">
                    <input type="hidden" name="jenis" value="tahunan">
                    <input type="hidden" name="harga" value="399000">
                    <button type="submit" name="bayar" class="btn-buy-neon btn-pulse">Pilih Tahunan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include("../index/footer.php"); ?>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init({ once: true });
</script>
</body>
</html>