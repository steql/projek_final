<?php
include("../index/db.php");

$user_id = $_SESSION['user_id'] ?? 0; 
$bahasa_id = $_GET['bahasa_id'] ?? $_SESSION['bahasa_id'] ?? 0;

if ($user_id == 0) {
    header("Location: login.php");
    exit();
}

if ($bahasa_id == 0) {
    header("Location: Home.php");
    exit();
}

$user_q = mysqli_query($conn, "SELECT is_premium FROM users WHERE user_id = $user_id");
$user_data = mysqli_fetch_assoc($user_q);
$is_premium = ($user_data['is_premium'] == 1);

$bahasa_query = mysqli_query($conn, "SELECT nama_bahasa FROM bahasa WHERE bahasa_id = $bahasa_id");
$bahasa_data = mysqli_fetch_assoc($bahasa_query);
$bahasa_name = $bahasa_data['nama_bahasa'] ?? 'Bahasa Tidak Dikenal';

$_SESSION['bahasa_id'] = $bahasa_id;
$_SESSION['bahasa'] = $bahasa_name;

include("../index/navbar.php");

$courses_query = "SELECT kursus_id, judul, level, deskripsi, urutan, is_free FROM kursus WHERE bahasa_id = $bahasa_id ORDER BY urutan ASC";
$courses_result = mysqli_query($conn, $courses_query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Progress Belajar <?= htmlspecialchars($bahasa_name) ?> | LinguiStudy</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/member-page/progress.css"> 
</head>
<body>

<section class="course-list-page">
    <div class="glow-bg"></div>
    <div class="container">
        <div class="header-section" data-aos="fade-down">
            <span class="badge-lang">Kurikulum <?= htmlspecialchars($bahasa_name) ?></span>
            <h1 class="page-title">Progress Belajar</h1>
        </div>

        <div class="course-container">
            <?php 
            if ($courses_result && mysqli_num_rows($courses_result) > 0) {
                $count = 0;
                while($course = mysqli_fetch_assoc($courses_result)) { 
                    $count++;
                    $kursus_id = $course['kursus_id'];
                    $urutan = $course['urutan'];
                    $is_free = $course['is_free'];
                    
                    $sub_locked = ($is_free == 0 && !$is_premium);
                    $order_locked = false;

                    if ($urutan > 1) {
                        $prev_order = $urutan - 1;
                        $cek_prev = mysqli_query($conn, "
                            SELECT COUNT(m.materi_id) as sisa 
                            FROM materi m
                            JOIN kursus k ON m.kursus_id = k.kursus_id
                            LEFT JOIN progres p ON m.materi_id = p.materi_id AND p.user_id = $user_id
                            WHERE k.urutan = $prev_order AND k.bahasa_id = $bahasa_id 
                            AND (p.status IS NULL OR p.status != 'selesai')
                        ");
                        $prev_data = mysqli_fetch_assoc($cek_prev);
                        if ($prev_data['sisa'] > 0) {
                            $order_locked = true;
                        }
                    }

                    $is_course_locked = ($sub_locked || $order_locked);
                    $box_class = $is_course_locked ? 'course-box locked' : 'course-box';
            ?>
                <div class="<?= $box_class ?>" data-aos="fade-up" data-aos-delay="<?= $count * 100 ?>">
                    <div class="course-header">
                        <div class="title-meta">
                            <span class="level-tag"><?= htmlspecialchars($course['level']) ?></span>
                            <h2><?= htmlspecialchars($course['judul']) ?></h2>
                        </div>
                        <div class="badges">
                            <?php if($sub_locked): ?>
                                <span class="lock-badge premium">💎 Premium Only</span>
                            <?php elseif($order_locked): ?>
                                <span class="lock-badge sequence">🔒 Level Terkunci</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <p class="course-description"><?= htmlspecialchars($course['deskripsi']) ?></p>

                    <div class="materials-list">
                        <?php 
                        $materi_query = mysqli_query($conn, "SELECT materi_id, judul FROM materi WHERE kursus_id = $kursus_id ORDER BY materi_id ASC");
                        if ($materi_query && mysqli_num_rows($materi_query) > 0) {
                            while($materi = mysqli_fetch_assoc($materi_query)) {
                                $materi_id = $materi['materi_id'];
                                $status_q = mysqli_query($conn, "SELECT status FROM progres WHERE user_id = $user_id AND materi_id = $materi_id");
                                $status_data = mysqli_fetch_assoc($status_q);
                                $is_done = ($status_data && $status_data['status'] == 'selesai');
                                
                                if ($is_course_locked) {
                                    echo "<div class='material-item item-locked'>";
                                } else {
                                    $materi_class = $is_done ? 'material-item completed' : 'material-item';
                                    echo "<a href='update-progress.php?materi_id=$materi_id' class='$materi_class'>";
                                }
                        ?>
                                    <div class="material-info">
                                        <div class="icon-indicator"></div>
                                        <h4><?= htmlspecialchars($materi['judul']) ?></h4>
                                    </div>
                                    <div class="status-indicator">
                                        <?php if ($is_done): ?>
                                            <span class="status-text done">Selesai</span>
                                        <?php elseif (!$is_course_locked): ?>
                                            <span class="status-text ready">Mulai</span>
                                        <?php else: ?>
                                            <span class="status-text disabled">Locked</span>
                                        <?php endif; ?>
                                    </div>
                        <?php 
                                echo $is_course_locked ? "</div>" : "</a>";
                            }
                        } 
                        ?>
                    </div>

                    <?php if ($sub_locked): ?>
                        <div class="upsell-container">
                            <a href="subscription.php" class="btn-upgrade">Upgrade ke Premium</a>
                        </div>
                    <?php endif; ?>
                </div>
            <?php 
                }
            } 
            ?>
        </div>
    </div>
</section>

<?php include("../index/footer.php"); ?>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init({ once: true });
</script>
</body>
</html>
<?php ob_end_flush(); ?>