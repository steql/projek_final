<?php
include("../index/index.php");
include("../index/navbar.php");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LinguiStudy | Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/member-page/dashboard.css">
</head>
<body>

<section class="hero-main">
    <div class="glow-overlay"></div>
    <div class="container hero-main-content">
        <div class="hero-main-text" data-aos="fade-right">
            <h1 class="main-heading">
                Platform Terbaik <br> 
                <span class="wipe-fill" data-text="BELAJAR ONLINE">BELAJAR ONLINE</span>
            </h1>
            <p class="subtitle">
                LinguiStudy membantu kamu belajar bahasa asing secara terstruktur,
                praktis, dan terukur melalui materi interaktif dan latihan harian.
            </p>

            <ul class="benefit-list">
                <li tabindex="0"><span class="dot"></span> Level Pemula - Mahir</li>
                <li tabindex="0"><span class="dot"></span> Latihan & Evaluasi</li>
                <li tabindex="0"><span class="dot"></span> Progres Otomatis</li>
                <li tabindex="0"><span class="dot"></span> Akses Kapan Saja</li>
                <li tabindex="0"><span class="dot"></span> Sertifikat Resmi</li>
                <li tabindex="0"><span class="dot"></span> Desain Kekinian</li>
            </ul>

            <div class="hero-action">
                <a href="register.php" class="btn-primary">Mulai Gratis</a>
                <a href="#fitur" class="btn-secondary">Pelajari lebih lanjut</a>
            </div>
        </div>

        <div class="hero-main-visual" data-aos="zoom-in">
            <div class="visual-logo-only floating">
                <img src="../logo.png" alt="Logo LinguiStudy">
            </div>
        </div>
    </div>
</section>

<section class="section" id="fitur">
    <div class="container">
        <h2 class="section-title" data-aos="fade-up">Layanan Unggulan Kami</h2>
        <div class="feature-grid">
            <div class="feature-card" data-aos="fade-up" data-aos-delay="100" tabindex="0">
                <div class="icon-box">📚</div>
                <h3>Materi Terstruktur</h3>
                <p>Materi belajar disusun sistematis sesuai level kemampuan.</p>
            </div>
            <div class="feature-card" data-aos="fade-up" data-aos-delay="200" tabindex="0">
                <div class="icon-box">✍️</div>
                <h3>Latihan Interaktif</h3>
                <p>Soal latihan membantu kamu memahami materi secara langsung.</p>
            </div>
            <div class="feature-card" data-aos="fade-up" data-aos-delay="300" tabindex="0">
                <div class="icon-box">📈</div>
                <h3>Pantauan Progres</h3>
                <p>Setiap perkembangan belajar tercatat dan mudah dipantau.</p>
            </div>
            <div class="feature-card" data-aos="fade-up" data-aos-delay="400" tabindex="0">
                <div class="icon-box">💎</div>
                <h3>Sistem Berlangganan</h3>
                <p>Akses penuh ke semua kursus melalui paket langganan.</p>
            </div>
        </div>
    </div>
</section>

<section class="cta" data-aos="fade-up">
    <div class="container">
        <div class="cta-box">
            <h2>Siap Menguasai Bahasa Baru?</h2>
            <p>Tingkatkan kemampuan bahasa asing kamu bersama LinguiStudy sekarang juga.</p>
            <a href="register.php" class="btn-cta">Daftar Sekarang</a>
        </div>
    </div>
</section>

<?php include("../index/footer.php"); ?>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init({ once: true });
</script>
</body>
</html>