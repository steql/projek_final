<?php
include("../index/db.php");

unset($_SESSION['bahasa'], $_SESSION['bahasa_id']);

include("../index/navbar.php");

$query = "SELECT bahasa_id, nama_bahasa FROM bahasa ORDER BY nama_bahasa ASC";
$result = mysqli_query($conn, $query);
if (!$result) {
    die("Query Error: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pilih Bahasa | LinguiStudy</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/member-page/home.css">
</head>
<body>

<div class="page" id="page">
<section class="home-hero">
    <div class="glow-bg"></div>

    <div class="container">
        <div class="header-box" data-aos="fade-down">
            <h1>Pilih Bahasa</h1>
            <p>Pilih petualangan bahasamu dan mulai belajar hari ini</p>
        </div>

        <div class="language-grid">
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php $delay = 0; ?>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <?php $delay += 100; ?>
                    <a href="progress.php?bahasa_id=<?= $row['bahasa_id']; ?>"
                       class="language-card"
                       data-url="progress.php?bahasa_id=<?= $row['bahasa_id']; ?>"
                       data-aos="fade-up"
                       data-aos-delay="<?= $delay; ?>">

                        <div class="card-glass"></div>

                        <div class="card-content">
                            <div class="lang-icon">
                                <?= strtoupper(mb_substr($row['nama_bahasa'],0,1)); ?>
                            </div>

                            <div class="lang-info">
                                <span class="lang-name">
                                    <?= htmlspecialchars($row['nama_bahasa']); ?>
                                </span>
                                <span class="lang-status">
                                    Tersedia Sekarang
                                </span>
                            </div>

                            <div class="arrow-circle">
                                <span class="arrow-icon">→</span>
                            </div>
                        </div>
                    </a>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-state" data-aos="zoom-in">
                    <p>Belum ada bahasa yang tersedia.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
</div>

<?php include("../index/footer.php"); ?>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="../js/home.js"></script>

</body>
</html>
