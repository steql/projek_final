<?php
session_start();
include("../index/index.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['bayar'])) {
    $user_id = $_SESSION['user_id'];
    $jenis = $_POST['jenis'];
    $total = $_POST['harga'];
    $tanggal = date('Y-m-d');
    
    if ($jenis == 'tahunan') {
        $durasi = 12;
        $label_durasi = "+12 months";
    } else {
        $durasi = 1;
        $label_durasi = "+1 month";
    }
    
    $premium_until = date('Y-m-d', strtotime($label_durasi));

    $query_transaksi = "INSERT INTO transaksi (user_id, tanggal, total) VALUES ('$user_id', '$tanggal', '$total')";
    
    if (mysqli_query($conn, $query_transaksi)) {
        $transaksi_id = mysqli_insert_id($conn);

        $query_detail = "INSERT INTO transaksi_detail (transaksi_id, jenis_subscribe, harga, durasi_bulan) 
                         VALUES ('$transaksi_id', '$jenis', '$total', '$durasi')";
        mysqli_query($conn, $query_detail);

        $query_user = "UPDATE users SET is_premium = 1, premium_until = '$premium_until' WHERE user_id = '$user_id'";
        mysqli_query($conn, $query_user);

        $_SESSION['success_message'] = "Pembayaran Berhasil! Paket " . ucfirst($jenis) . " aktif.";
        header("Location: Home.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {
    header("Location: subscription.php");
    exit();
}