<?php
include("../index/db.php");
include("../index/navbar.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $password = mysqli_real_escape_string($conn, $_POST["password"]);
    $remember = isset($_POST["remember"]);

    if (empty($email) || empty($password)) {
        $error = "Email dan password wajib diisi";
    } else {
        if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            $error = "Format email tidak valid";
        } else {
            $query = "SELECT * FROM users WHERE email='$email'";
            $result = mysqli_query($conn, $query);

            if (mysqli_num_rows($result) != 1) {
                $error = "Email tidak terdaftar";
            } else {
                $row = mysqli_fetch_assoc($result);
                if ($password !== $row["password"]) {
                    $error = "Password salah";
                } else {
                    $_SESSION["user_id"] = $row["user_id"];
                    $_SESSION["login_user"] = $row["nama"]; 
                    $_SESSION["login_email"] = $row["email"]; 
                    $_SESSION["current_role"] = $row["role"]; 

                    if ($remember) {
                        setcookie("user_id", $row["user_id"], time() + (3600 * 24 * 7), "/");
                    }

                    if ($row["role"] == "admin") {
                        header("Location: ../admin-page/admin-dashboard.php");
                        exit();
                    } else {
                        header("Location: Home.php");
                        exit();
                    }
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | LinguiStudy</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/member-page/login.css">
</head>
<body>

<div class="login-wrapper">
    <div class="glow-bg"></div>
    <div class="login-container" data-aos="zoom-in" data-aos-duration="1000">
        <form class="login-box" method="post">
            <h2>Login</h2>
            <p class="subtitle">Selamat datang kembali di LinguiStudy</p>

            <?php if (isset($_SESSION['success_message'])) : ?>
                <div class="success-box"><?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?></div>
            <?php endif; ?>

            <?php if ($error != "") : ?>
                <div class="error-box"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="input-group">
                <label>Email Address</label>
                <input type="email" name="email" id="email" placeholder="Masukkan email kamu" required>
                <div class="focus-border"></div>
            </div>
            
            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" id="password" placeholder="Masukkan password" required>
                <div class="focus-border"></div>
            </div>

            <div class="form-options">
                <label class="remember">
                    <input type="checkbox" name="remember" id="remember">
                    <span class="remember-text">Remember me</span>
                </label>
            </div>

            <button type="submit" name="login" class="btn-login-neon btn-pulse">Login Sekarang</button>
            
            <div class="register-link">
                Belum punya akun? <a href="register.php">Daftar sekarang</a>
            </div>
        </form>
    </div>
</div>

<?php include("../index/footer.php"); ?>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init({ once: true });
</script>
</body>
</html>