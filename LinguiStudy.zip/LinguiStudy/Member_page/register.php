<?php
include("../index/index.php");
include("../index/navbar.php");

$error = "";
$username_val = "";
$email_val = "";
$terms_checked = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["register"])) {
    $username = trim(mysqli_real_escape_string($conn, $_POST["username"]));
    $email = trim(mysqli_real_escape_string($conn, $_POST["email"]));
    $password = trim(mysqli_real_escape_string($conn, $_POST["password"]));
    $confirm = trim($_POST["confirm_password"]);
    $terms = isset($_POST["terms"]);

    $username_val = $username;
    $email_val = $email;
    $terms_checked = $terms ? 'checked' : '';

    if ($username == "" || $email == "" || $password == "" || $confirm == "") {
        $error = "Semua field wajib diisi";
    } elseif (strlen($username) < 5 || strlen($username) > 20) {
        $error = "Username harus 5 sampai 20 karakter";
    } elseif (strpos($email, "@gmail.com") === false) {
        $error = "Email harus menggunakan @gmail.com";
    } elseif (strlen($password) < 5) {
        $error = "Password minimal 5 karakter";
    } elseif ($password !== $confirm) {
        $error = "Password dan konfirmasi tidak sama";
    } elseif (!$terms) {
        $error = "Anda harus menyetujui terms and conditions";
    } else {
        $checkUser = mysqli_query($conn, "SELECT user_id FROM users WHERE nama='$username'");
        if (mysqli_num_rows($checkUser) > 0) {
            $error = "Username sudah digunakan";
        } else {
            $checkEmail = mysqli_query($conn, "SELECT user_id FROM users WHERE email='$email'");
            if (mysqli_num_rows($checkEmail) > 0) {
                $error = "Email sudah terdaftar";
            } else {
                $query = "INSERT INTO users (nama, email, password, role) VALUES ('$username','$email','$password','user')";
                if (mysqli_query($conn, $query)) {
                    $_SESSION['success_message'] = "Registrasi berhasil. Silakan login.";
                    header("Location: login.php");
                    exit();
                } else {
                    $error = "Registrasi gagal: " . mysqli_error($conn);
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | LinguiStudy</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/member-page/register.css">
</head>
<body>

<div class="register-wrapper">
    <div class="glow-bg"></div>
    <div class="register-container" data-aos="zoom-in" data-aos-duration="1000">
        <div class="register-box">
            <h2>Register Akun</h2>
            <p class="subtitle">Mulai petualangan belajarmu bersama LinguiStudy</p>

            <?php if ($error != "") : ?>
                <div class="error-box"><?php echo $error; ?></div>
            <?php endif; ?>

            <form method="post">
                <div class="input-group">
                    <label>Username</label>
                    <input type="text" name="username" placeholder="Masukkan username" value="<?= htmlspecialchars($username_val) ?>" required>
                    <div class="focus-border"></div>
                </div>
                <div class="input-group">
                    <label>Email Address</label>
                    <input type="email" name="email" placeholder="contoh@gmail.com" value="<?= htmlspecialchars($email_val) ?>" required>
                    <div class="focus-border"></div>
                </div>
                <div class="input-group">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Minimal 5 karakter" required>
                    <div class="focus-border"></div>
                </div>
                <div class="input-group">
                    <label>Konfirmasi Password</label>
                    <input type="password" name="confirm_password" placeholder="Ulangi password" required>
                    <div class="focus-border"></div>
                </div>
                
                <div class="terms-area">
                    <label class="terms-label">
                        <input type="checkbox" name="terms" <?= $terms_checked ?>>
                        <span class="terms-text">Saya setuju dengan Terms & Conditions</span>
                    </label>
                </div>

                <button type="submit" name="register" class="btn-register-neon">Daftar Sekarang</button>
            </form>

            <div class="login-footer">
                Sudah punya akun? <a href="login.php">Login di sini</a>
            </div>
        </div>
    </div>
</div>

<?php include("../index/footer.php"); ?>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init({ once: true });
</script>
</body>
</html>