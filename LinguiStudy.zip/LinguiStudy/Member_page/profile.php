<?php
ob_start();
include("../index/db.php");

$user_id = $_SESSION['user_id'] ?? 0;
if ($user_id == 0) {
    header("Location: login.php");
    exit();
}

$status_msg = "";
$status_type = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $query_current = mysqli_query($conn, "SELECT password FROM users WHERE user_id = $user_id");
    $db_data = mysqli_fetch_assoc($query_current);

    if (isset($_POST['update_profile'])) {
        $nama_baru = mysqli_real_escape_string($conn, $_POST['nama']);
        $email_baru = mysqli_real_escape_string($conn, $_POST['email']);
        $update = mysqli_query($conn, "UPDATE users SET nama = '$nama_baru', email = '$email_baru' WHERE user_id = $user_id");
        if ($update) {
            $_SESSION['login_user'] = $nama_baru;
            $status_msg = "Profil berhasil diperbarui!";
            $status_type = "success";
        }
    }

    if (isset($_POST['change_password'])) {
        $pw_lama_input = trim($_POST['current_password']); 
        $pw_baru = trim($_POST['new_password']);
        $pw_di_database = $db_data['password'];

        if ($pw_lama_input === $pw_di_database) {
            $update_pw = mysqli_query($conn, "UPDATE users SET password = '$pw_baru' WHERE user_id = $user_id");
            if ($update_pw) {
                $status_msg = "Password berhasil diubah!";
                $status_type = "success";
            }
        } else {
            $status_msg = "Password saat ini salah!";
            $status_type = "error";
        }
    }

    if (isset($_POST['delete_account'])) {
        mysqli_query($conn, "DELETE FROM progres WHERE user_id = $user_id");
        mysqli_query($conn, "DELETE FROM transaksi WHERE user_id = $user_id");
        $delete = mysqli_query($conn, "DELETE FROM users WHERE user_id = $user_id");
        if ($delete) {
            session_destroy();
            header("Location: register.php");
            exit();
        }
    }
}

$query_user = mysqli_query($conn, "SELECT * FROM users WHERE user_id = $user_id");
$user = mysqli_fetch_assoc($query_user);

include("../index/navbar.php");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings | LinguiStudy</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/member-page/profile.css">
</head>
<body>
    <section class="profile-page">
        <div class="glow-bg"></div>
        <div class="profile-wrapper" data-aos="fade-up">
            <aside class="profile-sidebar">
                <div class="user-info">
                    <div class="avatar-large"><?= strtoupper(substr($user['nama'] ?? 'U', 0, 1)) ?></div>
                    <h3><?= htmlspecialchars($user['nama']) ?></h3>
                    <p><?= htmlspecialchars($user['email']) ?></p>
                </div>
                <nav class="side-nav">
                    <button onclick="showTab('edit-profile')" class="nav-btn active">👤 Edit Profile</button>
                    <button onclick="showTab('change-password')" class="nav-btn">🔑 Change Password</button>
                    <button onclick="showTab('danger-zone')" class="nav-btn btn-danger-nav">⚠️ Delete Account</button>
                </nav>
            </aside>

            <main class="profile-content">
                <?php if (!empty($status_msg)): ?>
                    <div class="alert alert-<?= $status_type ?>"><?= $status_msg ?></div>
                <?php endif; ?>

                <div id="edit-profile" class="tab-content active">
                    <h2>Account Settings</h2>
                    <form method="POST">
                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" name="nama" value="<?= htmlspecialchars($user['nama']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Email Address</label>
                            <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                        </div>
                        <button type="submit" name="update_profile" class="main-btn-neon">Save Changes</button>
                    </form>
                </div>

                <div id="change-password" class="tab-content">
                    <h2>Privacy</h2>
                    <form method="POST">
                        <div class="form-group">
                            <label>Current Password</label>
                            <input type="password" name="current_password" required autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" name="new_password" required autocomplete="off">
                        </div>
                        <button type="submit" name="change_password" class="main-btn-neon">Update Password</button>
                    </form>
                </div>

                <div id="danger-zone" class="tab-content">
                    <h2 style="color: #ff4757;">Danger Zone</h2>
                    <p class="danger-desc">Menghapus akun akan menghilangkan semua riwayat belajar secara permanen.</p>
                    <form method="POST" onsubmit="return confirm('Hapus akun secara permanen?');">
                        <button type="submit" name="delete_account" class="del-btn-neon">Permanently Delete Account</button>
                    </form>
                </div>
            </main>
        </div>
    </section>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="../js/profile.js"></script>
    <script>
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>
<?php ob_end_flush(); ?>