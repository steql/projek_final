<?php
include("../index/db.php");

$user_id = $_SESSION['user_id'] ?? 0;
$materi_id = $_GET['materi_id'] ?? 0;

if ($user_id == 0 || $materi_id == 0) {
    header("Location: login.php");
    exit();
}

$check_query = "SELECT progres_id FROM progres WHERE user_id = $user_id AND materi_id = $materi_id";
$check_result = mysqli_query($conn, $check_query);

if (mysqli_num_rows($check_result) > 0) {
    $update_query = "UPDATE progres SET status = 'selesai', updated_at = NOW() WHERE user_id = $user_id AND materi_id = $materi_id";
    mysqli_query($conn, $update_query);
} else {
    $insert_query = "INSERT INTO progres (user_id, materi_id, status) VALUES ($user_id, $materi_id, 'selesai')";
    mysqli_query($conn, $insert_query);
}

$kursus_id_q = mysqli_query($conn, "SELECT kursus_id FROM materi WHERE materi_id = $materi_id");
$kursus_id_data = mysqli_fetch_assoc($kursus_id_q);
$kursus_id = $kursus_id_data['kursus_id'] ?? 0;

if ($kursus_id > 0) {
    $bahasa_id_q = mysqli_query($conn, "SELECT bahasa_id FROM kursus WHERE kursus_id = $kursus_id");
    $bahasa_id_data = mysqli_fetch_assoc($bahasa_id_q);
    $bahasa_id = $bahasa_id_data['bahasa_id'] ?? 0;

    if ($bahasa_id > 0) {

        header("Location: progress.php?bahasa_id=" . $bahasa_id);
        exit();
    }
}

header("Location: Home.php");
exit();
?>