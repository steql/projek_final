<?php
ob_start();
include("../index/index.php");

$user_id = $_SESSION['user_id'] ?? 0;
$bahasa_id = $_SESSION['bahasa_id'] ?? 0;

if ($user_id == 0) {
    header("Location: login.php");
    exit();
}

if ($bahasa_id == 0) {
    header("Location: Home.php");
    exit();
}

include("../index/navbar.php");

$completed_query = "
    SELECT M.judul as materi_judul, K.judul as kursus_judul, K.level, P.updated_at, B.nama_bahasa
    FROM progres P
    JOIN materi M ON P.materi_id = M.materi_id
    JOIN kursus K ON M.kursus_id = K.kursus_id
    JOIN bahasa B ON K.bahasa_id = B.bahasa_id
    WHERE P.user_id = $user_id 
    AND P.status = 'selesai' 
    AND K.bahasa_id = $bahasa_id
    ORDER BY P.updated_at DESC
";
$completed_result = mysqli_query($conn, $completed_query);

$b_name_q = mysqli_query($conn, "SELECT nama_bahasa FROM bahasa WHERE bahasa_id = $bahasa_id");
$b_data = mysqli_fetch_assoc($b_name_q);
$current_lang = $b_data['nama_bahasa'] ?? '';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aktivitas Belajar <?= $current_lang ?> | LinguiStudy</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/member-page/activities.css">
</head>
<body>

<section class="activities-page">
    <div class="glow-bg"></div>
    <div class="container">
        <div class="header-section" data-aos="fade-down">
            <h1>Riwayat Aktivitas</h1>
            <p>Progres belajar kamu di Bahasa <strong><?= htmlspecialchars($current_lang) ?></strong></p>
        </div>

        <div class="activities-timeline">
            <?php 
            if (mysqli_num_rows($completed_result) > 0) {
                $count = 0;
                while($row = mysqli_fetch_assoc($completed_result)) { 
                    $count++;
                    $date = date('d M Y, H:i', strtotime($row['updated_at']));
                ?>
                <div class="activity-card" data-aos="fade-left" data-aos-delay="<?= $count * 100 ?>">
                    <div class="card-left">
                        <div class="status-icon-circle">
                            <span class="check-mark">✓</span>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="meta-info">
                            <span class="badge-lang"><?= htmlspecialchars($row['nama_bahasa']) ?></span>
                            <span class="badge-level"><?= strtoupper($row['level']) ?></span>
                        </div>
                        <h3><?= htmlspecialchars($row['materi_judul']) ?></h3>
                        <p class="course-text"><?= htmlspecialchars($row['kursus_judul']) ?></p>
                        <div class="timestamp-box">
                            <span class="clock-icon">🕒</span>
                            <?= $date ?> WIB
                        </div>
                    </div>
                    <div class="card-glow"></div>
                </div>
            <?php 
                }
            } else {
                echo "
                <div class='empty-state' data-aos='zoom-in'>
                    <div class='empty-icon-box'>📚</div>
                    <h3>Belum ada materi selesai</h3>
                    <p>Kamu belum menyelesaikan materi apapun di bahasa ini.</p>
                    <a href='progress.php?bahasa_id=$bahasa_id' class='btn-start-now'>Mulai Belajar</a>
                </div>";
            }
            ?>
        </div>
    </div>
</section>

<?php include("../index/footer.php"); ?>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init({ once: true });
</script>
</body>
</html>
<?php ob_end_flush(); ?>