<?php
ob_start();
include("../index/db.php");
include("../index/navbar.php");


if (!isset($_SESSION['current_role']) || $_SESSION['current_role'] !== 'admin') {
    header("Location: ../Member_page/login.php");
    exit();
}

$transaksi_q = mysqli_query($conn, "SELECT transaksi.*, users.nama, users.email 
                                    FROM transaksi 
                                    JOIN users ON transaksi.user_id = users.user_id 
                                    ORDER BY transaksi.transaksi_id ASC");

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi | LinguiStudy Admin</title>
    <link rel="stylesheet" href="../css/admin-page/transaksi.css">
</head>
<body>

<div class="admin-layout">
    <?php include("../index/sidebar.php"); ?>

    <main class="main-content">
        <header class="content-header">
            <h2>Transaction Management</h2>
            <p>Total transaksi: <?= mysqli_num_rows($transaksi_q) ?> data terdeteksi</p>
        </header>

        <div class="table-card">
            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width: 80px;">ID</th>
                        <th>USER</th>
                        <th>EMAIL</th>
                        <th>TANGGAL</th>
                        <th style="text-align: right;">TOTAL</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($transaksi_q)): ?>
                    <tr>
                        <td class="id-cell">#<?= $row['transaksi_id'] ?></td>
                        <td class="name-cell"><strong><?= htmlspecialchars($row['nama']) ?></strong></td>
                        <td class="email-cell"><?= htmlspecialchars($row['email']) ?></td>
                        <td class="date-cell"><?= date('d M Y', strtotime($row['tanggal'])) ?></td>
                        <td style="text-align: right;" class="amount-cell">
                            Rp <?= number_format($row['total'], 0, ',', '.') ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

</body>
</html>
<?php ob_end_flush(); ?>