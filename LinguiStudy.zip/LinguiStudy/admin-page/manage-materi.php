<?php
ob_start();
include("../index/db.php");
include("../index/navbar.php");

if (!isset($_SESSION['current_role']) || $_SESSION['current_role'] !== 'admin') {
    header("Location: ../Member_page/login.php");
    exit();
}

if (isset($_POST['save_materi'])) {
    $kursus_id = mysqli_real_escape_string($conn, $_POST['kursus_id']);
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $konten = mysqli_real_escape_string($conn, $_POST['konten']);
    mysqli_query($conn, "INSERT INTO materi (kursus_id, judul, konten) VALUES ('$kursus_id', '$judul', '$konten')");
    header("Location: manage-materi.php");
    exit();
}

if (isset($_GET['delete_id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete_id']);
    mysqli_query($conn, "DELETE FROM materi WHERE materi_id = $id");
    header("Location: manage-materi.php");
    exit();
}

$stats_q = mysqli_query($conn, "SELECT k.judul as nama_kursus, COUNT(m.materi_id) as total FROM kursus k LEFT JOIN materi m ON k.kursus_id = m.kursus_id GROUP BY k.kursus_id");
$materi_q = mysqli_query($conn, "SELECT m.*, k.judul as nama_kursus FROM materi m JOIN kursus k ON m.kursus_id = k.kursus_id ORDER BY m.materi_id DESC");
$bahasa_q = mysqli_query($conn, "SELECT * FROM bahasa");
$kursus_all_q = mysqli_query($conn, "SELECT * FROM kursus");
$kursus_data = [];
while($k = mysqli_fetch_assoc($kursus_all_q)) { $kursus_data[] = $k; }
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manage Materi | Cyber Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/admin-page/manage-kursus.css">
    <link rel="stylesheet" href="../css/admin-page/manage-materi.css">
</head>
<body>

<div class="admin-layout">
    <?php include("../index/sidebar.php"); ?>

    <main class="main-content">
        <header class="content-header">
            <div class="header-top">
                <h2>Manage Materi</h2>
                <button class="btn-add-main" onclick="openModal()">+ Add Materi</button>
            </div>
            
            <div class="stat-grid">
                <?php mysqli_data_seek($stats_q, 0); while($s = mysqli_fetch_assoc($stats_q)): ?>
                <div class="stat-card" onclick="filterByCourse('<?= addslashes($s['nama_kursus']) ?>', this)">
                    <span><?= htmlspecialchars($s['nama_kursus']) ?></span>
                    <strong><?= $s['total'] ?> Materi</strong>
                </div>
                <?php endwhile; ?>
            </div>
        </header>

        <div id="addMateriModal" class="modal-overlay">
            <div class="modal-card">
                <form method="POST">
                    <h3>Add New Materi</h3>
                    <div class="form-group">
                        <label>Language</label>
                        <select id="sel_bahasa" onchange="loadKursus()" required>
                            <option value="">Select Language</option>
                            <?php mysqli_data_seek($bahasa_q, 0); while($b = mysqli_fetch_assoc($bahasa_q)): ?>
                                <option value="<?= $b['bahasa_id'] ?>"><?= $b['nama_bahasa'] ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Course</label>
                        <select name="kursus_id" id="sel_kursus" disabled required>
                            <option value="">Select Language First</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Materi Title</label>
                        <input type="text" name="judul" placeholder="Enter materi title..." required>
                    </div>
                    <div class="form-group">
                        <label>Content</label>
                        <textarea name="konten" placeholder="Enter materi content..." required></textarea>
                    </div>
                    <div class="modal-actions">
                        <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                        <button type="submit" name="save_materi" class="btn-save">Save Materi</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="table-card">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>JUDUL MATERI</th>
                        <th>KURSUS</th>
                        <th style="text-align: right;">AKSI</th>
                    </tr>
                </thead>
                <tbody id="materiBody">
                    <?php mysqli_data_seek($materi_q, 0); while($row = mysqli_fetch_assoc($materi_q)): ?>
                    <tr class="course-row" data-course="<?= htmlspecialchars($row['nama_kursus']) ?>">
                        <td><strong><?= htmlspecialchars($row['judul']) ?></strong></td>
                        <td><span class="badge-lang"><?= htmlspecialchars($row['nama_kursus']) ?></span></td>
                        <td style="text-align: right;">
                            <a href="?delete_id=<?= $row['materi_id'] ?>" class="btn-delete" onclick="return confirm('Hapus?')">Delete</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<script>
    const kursusList = <?= json_encode($kursus_data); ?>;
</script>
<script src="../js/manage-materi.js"></script>

</body>
</html>
<?php ob_end_flush(); ?>