<?php
ob_start();
include("../index/index.php");
include("../index/navbar.php");

if (!isset($_SESSION['current_role']) || $_SESSION['current_role'] !== 'admin') {
    header("Location: ../index/login.php");
    exit();
}

if (isset($_GET['delete_id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete_id']);
    mysqli_query($conn, "DELETE FROM progres WHERE user_id = $id");
    mysqli_query($conn, "DELETE FROM transaksi WHERE user_id = $id");
    mysqli_query($conn, "DELETE FROM users WHERE user_id = $id AND role != 'admin'");
    header("Location: manage-user.php");
    exit();
}

$users_q = mysqli_query($conn, "SELECT * FROM users WHERE role = 'user' ORDER BY created_at DESC");

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage User | LinguiStudy Admin</title>
    <link rel="stylesheet" href="../css/admin-page/manage-user.css">
</head>
<body>

<div class="admin-layout">
    <?php include("../index/sidebar.php"); ?>

    <main class="main-content">
        <header class="content-header">
            <h2>User Management</h2>
            <p>Total terdaftar: <?= mysqli_num_rows($users_q) ?> pengguna</p>
        </header>

        <div class="table-card">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>USER</th>
                        <th>EMAIL</th>
                        <th>SUBSCRIPTION</th>
                        <th>JOIN DATE</th>
                        <th style="text-align: right;">ACTIONS</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($users_q)): ?>
                    <tr>
                        <td>
                            <div class="user-cell">
                                <div class="avatar" style="background: #5b2cff;">
                                    <?= strtoupper(substr($row['nama'], 0, 1)) ?>
                                </div>
                                <span><?= htmlspecialchars($row['nama']) ?></span>
                            </div>
                        </td>
                        <td style="color: rgba(255,255,255,0.6);"><?= htmlspecialchars($row['email']) ?></td>
                        <td>
                            <?php if($row['is_premium']): ?>
                                <span class="badge badge-premium">Premium</span>
                            <?php else: ?>
                                <span class="badge badge-free">Free Member</span>
                            <?php endif; ?>
                        </td>
                        <td style="color: rgba(255,255,255,0.6);"><?= date('d M Y', strtotime($row['created_at'])) ?></td>
                        <td style="text-align: right;">
                            <a href="manage-user.php?delete_id=<?= $row['user_id'] ?>" 
                               class="btn-delete" 
                               onclick="return confirm('Apakah Anda yakin ingin menghapus user ini?')">
                               Delete
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

</body>
</html>
<?php ob_end_flush(); ?>