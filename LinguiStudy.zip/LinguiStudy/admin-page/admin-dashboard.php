<?php
ob_start();
include("../index/db.php");
include("../index/navbar.php");

if (!isset($_SESSION['current_role']) || $_SESSION['current_role'] !== 'admin') {
    header("Location: ../Member_page/login.php");
    exit();
}

$total_user_q = mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE role = 'user'");
$total_user = ($total_user_q) ? mysqli_fetch_assoc($total_user_q)['total'] : 0;

$total_subs_q = mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE is_premium = 1");
$total_subs = ($total_subs_q) ? mysqli_fetch_assoc($total_subs_q)['total'] : 0;

$revenue_q = mysqli_query($conn, "SELECT SUM(total) as total_revenue FROM transaksi");
$revenue = 0;
if ($revenue_q) {
    $row_revenue = mysqli_fetch_assoc($revenue_q);
    $revenue = $row_revenue['total_revenue'] ?? 0;
}

$activity_data = [];
$labels = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $labels[] = date('D', strtotime($date));
    $check_act = mysqli_query($conn, "SELECT COUNT(*) as total FROM progres WHERE DATE(updated_at) = '$date' AND status = 'selesai'");
    $activity_data[] = ($check_act) ? mysqli_fetch_assoc($check_act)['total'] : 0;
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | LinguiStudy Admin</title>
    <link rel="stylesheet" href="../css/admin-page/admin-dashboard.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<div class="admin-layout">
    <?php include("../index/sidebar.php"); ?>

    <main class="main-content">
        <header class="content-header">
            <h2>Statistik Platform</h2>
            <p>Ringkasan performa LinguiStudy hari ini.</p>
        </header>

        <div class="quick-stats">
            <div class="stat-card">
                <div class="stat-info">
                    <span>TOTAL USERS</span>
                    <strong><?= number_format($total_user) ?></strong>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-info">
                    <span>ACTIVE SUBS</span>
                    <strong><?= number_format($total_subs) ?></strong>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-info">
                    <span>REVENUE</span>
                    <strong class="text-cyan">Rp <?= number_format($revenue, 0, ',', '.') ?></strong>
                </div>
            </div>
        </div>

        <section class="chart-section">
            <div class="chart-container-card">
                <h3>User Activity (Daily)</h3>
                <div class="canvas-wrapper">
                    <canvas id="activityChart" 
                        data-labels='<?= json_encode($labels) ?>' 
                        data-values='<?= json_encode($activity_data) ?>'>
                    </canvas>
                </div>
            </div>
        </section>
    </main>
</div>

<script src="../js/admin-dashboard.js"></script>

</body>
</html>
<?php ob_end_flush(); ?>