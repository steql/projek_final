<?php
ob_start();
include("../index/index.php");
include("../index/navbar.php");

if (!isset($_SESSION['current_role']) || $_SESSION['current_role'] !== 'admin') {
    header("Location: ../index/login.php");
    exit();
}

if (isset($_POST['save_course'])) {
    $bahasa_id = mysqli_real_escape_string($conn, $_POST['bahasa_id']);
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
    $level = mysqli_real_escape_string($conn, $_POST['level']);
    
    $is_free = ($level == 'pemula') ? 1 : 0;
    $urutan = ($level == 'pemula') ? 1 : 2;

    mysqli_query($conn, "INSERT INTO kursus (bahasa_id, judul, deskripsi, level, is_free, urutan) 
                         VALUES ('$bahasa_id', '$judul', '$deskripsi', '$level', '$is_free', '$urutan')");
    
    header("Location: manage-kursus.php");
    exit();
}

if (isset($_GET['delete_id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete_id']);
    mysqli_query($conn, "DELETE FROM kursus WHERE kursus_id = $id");
    header("Location: manage-kursus.php");
    exit();
}

$stats_q = mysqli_query($conn, "SELECT b.nama_bahasa, COUNT(k.kursus_id) as total FROM bahasa b LEFT JOIN kursus k ON b.bahasa_id = k.bahasa_id GROUP BY b.bahasa_id");
$kursus_q = mysqli_query($conn, "SELECT k.*, b.nama_bahasa FROM kursus k JOIN bahasa b ON k.bahasa_id = b.bahasa_id ORDER BY k.kursus_id DESC");
$bahasa_filter = mysqli_query($conn, "SELECT * FROM bahasa");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Kursus | LinguiStudy Admin</title>
    <link rel="stylesheet" href="../css/admin-page/manage-kursus.css">
</head>
<body>

<div class="admin-layout">
    <?php include("../index/sidebar.php"); ?>

    <main class="main-content">
        <header class="content-header">
            <div class="header-top">
                <h2>Manage Course</h2>
                <button class="btn-add-main" onclick="openModal()">+ Add Course</button>
            </div>
            
            <div class="stat-grid">
                <?php while($s = mysqli_fetch_assoc($stats_q)): ?>
                <div class="stat-card">
                    <span><?= htmlspecialchars($s['nama_bahasa']) ?></span>
                    <strong><?= $s['total'] ?> Kursus</strong>
                </div>
                <?php endwhile; ?>
            </div>

            <div class="filter-wrapper">
                <button class="filter-btn active" onclick="filterLanguage(this, 'all')">Semua</button>
                <?php mysqli_data_seek($bahasa_filter, 0); while($f = mysqli_fetch_assoc($bahasa_filter)): ?>
                    <button class="filter-btn" onclick="filterLanguage(this, '<?= strtolower($f['nama_bahasa']) ?>')">
                        <?= htmlspecialchars($f['nama_bahasa']) ?>
                    </button>
                <?php endwhile; ?>
            </div>
        </header>

        <div id="addCourseModal" class="modal-overlay">
            <div class="modal-card">
                <form method="POST">
                    <h3>Add New Course</h3>
                    <div class="form-group">
                        <label>Language</label>
                        <select name="bahasa_id" required>
                            <option value="">Select Language</option>
                            <?php mysqli_data_seek($bahasa_filter, 0); while($b = mysqli_fetch_assoc($bahasa_filter)): ?>
                                <option value="<?= $b['bahasa_id'] ?>"><?= $b['nama_bahasa'] ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Level</label>
                        <select name="level" required>
                            <option value="pemula">Pemula (Free)</option>
                            <option value="menengah">Menengah (Premium)</option>
                            <option value="mahir">Mahir (Premium)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Course Title</label>
                        <input type="text" name="judul" placeholder="Enter course title..." required>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="deskripsi" placeholder="Enter course description..."></textarea>
                    </div>
                    <div class="modal-actions">
                        <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                        <button type="submit" name="save_course" class="btn-save">Save Course</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="table-card">
            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width: 35%;">JUDUL KURSUS</th>
                        <th style="width: 15%;">BAHASA</th>
                        <th style="width: 15%;">LEVEL</th>
                        <th style="width: 15%;">AKSES</th>
                        <th style="text-align: right; width: 20%;">AKSI</th>
                    </tr>
                </thead>
                <tbody id="courseTableBody">
                    <?php while($row = mysqli_fetch_assoc($kursus_q)): ?>
                    <tr class="course-row" data-language="<?= strtolower($row['nama_bahasa']) ?>">
                        <td><strong><?= htmlspecialchars($row['judul']) ?></strong></td>
                        <td><span class="badge-lang"><?= htmlspecialchars($row['nama_bahasa']) ?></span></td>
                        <td><span style="text-transform: capitalize; font-weight: 600;"><?= htmlspecialchars($row['level']) ?></span></td>
                        <td>
                            <?php if($row['is_free'] == 1): ?>
                                <span style="color: #00f2fe; font-size: 11px; font-weight: 800;">FREE</span>
                            <?php else: ?>
                                <span style="color: #ff5c6c; font-size: 11px; font-weight: 800;">PREMIUM</span>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: right;">
                            <a href="?delete_id=<?= $row['kursus_id'] ?>" class="btn-delete" onclick="return confirm('Hapus kursus?')">Delete</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<script src="../js/manage-kursus.js"></script>

</body>
</html>
<?php ob_end_flush(); ?>