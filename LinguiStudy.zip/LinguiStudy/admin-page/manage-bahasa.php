<?php
ob_start();
include("../index/index.php");
include("../index/navbar.php");


if (!isset($_SESSION['current_role']) || $_SESSION['current_role'] !== 'admin') {
    header("Location: ../index/login.php");
    exit();
}

if (isset($_POST['add_bahasa'])) {
    $nama_bahasa = mysqli_real_escape_string($conn, $_POST['nama_bahasa']);
    if (!empty($nama_bahasa)) {
        mysqli_query($conn, "INSERT INTO bahasa (nama_bahasa) VALUES ('$nama_bahasa')");
    }
    header("Location: manage-bahasa.php");
    exit();
}

if (isset($_GET['delete_id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete_id']);
    mysqli_query($conn, "DELETE FROM bahasa WHERE bahasa_id = $id");
    header("Location: manage-bahasa.php");
    exit();
}

$bahasa_q = mysqli_query($conn, "SELECT * FROM bahasa ORDER BY bahasa_id ASC");

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bahasa | LinguiStudy Admin</title>
    <link rel="stylesheet" href="../css/admin-page/manage-bahasa.css">
</head>
<body>

<div class="admin-layout">
    <?php include("../index/sidebar.php"); ?>

    <main class="main-content">
        <header class="content-header">
            <h2>Bahasa Management</h2>
            <p>Total tersedia: <?= mysqli_num_rows($bahasa_q) ?> bahasa</p>
        </header>

        <div class="form-card">
            <form method="POST" class="add-form">
                <input type="text" name="nama_bahasa" placeholder="Masukkan nama bahasa baru..." required>
                <button type="submit" name="add_bahasa" class="btn-submit">Tambah Bahasa</button>
            </form>
        </div>

        <div class="table-card">
            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width: 100px;">ID</th>
                        <th>NAMA BAHASA</th>
                        <th style="text-align: right;">ACTIONS</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($bahasa_q)): ?>
                    <tr>
                        <td class="id-cell">#<?= $row['bahasa_id'] ?></td>
                        <td>
                            <span class="lang-name"><?= htmlspecialchars($row['nama_bahasa']) ?></span>
                        </td>
                        <td style="text-align: right;">
                            <a href="manage-bahasa.php?delete_id=<?= $row['bahasa_id'] ?>" 
                               class="btn-delete" 
                               onclick="return confirm('Menghapus bahasa akan menghapus kursus terkait. Lanjutkan?')">
                               Delete
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

</body>
</html>
<?php ob_end_flush(); ?>