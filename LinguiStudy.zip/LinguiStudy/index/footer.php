<link rel="stylesheet" href="../css/main-page/footer.css">
<footer class="footer">
    <div class="footer-container">
        <div class="footer-left">
            <div class="footer-logo">LinguiStudy</div>
            <p>Tingkatkan kemampuan bahasa asing kamu dengan metode belajar yang interaktif dan terstruktur.</p>
            <div class="footer-contact">
                <p><span>📞</span> +62 812 3456 7890</p>
                <p><span>📧</span> support@linguistudy.com</p>
            </div>
        </div>

        <div class="footer-center">
            <h4>Informasi</h4>
            <a href="#">Tentang Kami</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms & Conditions</a>
        </div>

        <div class="footer-right">
            <h4>Bantuan</h4>
            <a href="#">FAQ</a>
            <a href="#">Kontak</a>
        </div>
    </div>

    <div class="footer-bottom">
        &copy; 2026 LinguiStudy. All rights reserved.
    </div>
</footer>