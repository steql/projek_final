<?php
    session_start();
    session_destroy();
    header("Location: ../Member_page/Dashboard.php");
    exit();
?>