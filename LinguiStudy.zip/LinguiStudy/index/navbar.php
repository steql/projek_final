<?php
$role = $_SESSION['current_role'] ?? 'guest';
$nama = $_SESSION['login_user'] ?? '';
$bahasa = $_SESSION['bahasa'] ?? '';
$bahasa_id = $_SESSION['bahasa_id'] ?? 0;
$user_id = $_SESSION['user_id'] ?? 0;

$is_premium = false;
if ($role === 'user' && $user_id != 0) {
    $check_premium = mysqli_query($conn, "SELECT is_premium FROM users WHERE user_id = $user_id");
    $u_data = mysqli_fetch_assoc($check_premium);
    if ($u_data && $u_data['is_premium'] == 1) {
        $is_premium = true;
    }
}
?>
<link rel="stylesheet" href="../css/main-page/navbar.css">

<header class="navbar">
    <div class="navbar-container">
        <div class="nav-left">
            <div class="logo">LinguiStudy</div>
            
            <?php if ($role === 'user' || $role === 'guest') : ?>
                <a href="dashboard.php" class="nav-link">Home</a>
            <?php endif; ?>

            <?php if ($role === 'admin') : ?>
                <a href="../admin-page/admin-dashboard.php" class="nav-link">Dashboard</a>
            <?php endif; ?>

            <?php if ($role === 'user') : ?>
                <?php if (!empty($bahasa) && $bahasa_id != 0) : ?>
                    <a href="progress.php?bahasa_id=<?= $bahasa_id ?>" class="nav-link">Progress</a>
                    <a href="Home.php" class="language-box"><?= strtoupper(htmlspecialchars($bahasa)) ?></a> 
                    <a href="activities.php" class="nav-link">Activities</a>
                <?php else : ?>
                    <a href="Home.php" class="nav-link">Pilih Bahasa</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="nav-right">
            <?php if ($role === 'guest') : ?>
                <a href="login.php" class="btn-login">Login</a>
                <a href="register.php" class="btn-register-dark">Register</a>
            <?php endif; ?>

            <?php if ($role === 'admin' || $role === 'user') : ?>
                <?php if ($role === 'user' && !$is_premium) : ?>
                    <a href="subscription.php" class="btn-subs-dark">Subscription</a>
                <?php endif; ?>
                
                <details class="profile-dropdown">
                    <summary class="profile-trigger">
                        <div class="profile-avatar">
                            <?= strtoupper(substr($nama, 0, 1)) ?>
                        </div>
                        <div class="name-container">
                            <span class="profile-name"><?= htmlspecialchars($nama) ?></span>
                            <?php if ($is_premium) : ?>
                                <span class="premium-badge">PREMIUM MEMBER</span>
                            <?php endif; ?>
                        </div>
                    </summary>
                    
                    <div class="dropdown-content">
                        <a href="../Member_page/profile.php" class="dropdown-item">👤 My profile</a>
                        <div class="dropdown-divider"></div>
                        <a href="../index/logout.php" class="dropdown-item logout-item">⏻ Logout</a>
                    </div>
                </details>
            <?php endif; ?>
        </div>
    </div>
</header>