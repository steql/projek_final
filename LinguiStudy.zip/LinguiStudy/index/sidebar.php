<link rel="stylesheet" href="../css/main-page/sidebar.css">
<aside class="sidebar">
    <nav class="sidebar-nav">
        <?php $current_page = basename($_SERVER['PHP_SELF']); ?>
        
        <a href="admin-dashboard.php" class="nav-item <?= ($current_page == 'admin-dashboard.php') ? 'active' : '' ?>">Home</a>
        <a href="manage-user.php" class="nav-item <?= ($current_page == 'manage-user.php') ? 'active' : '' ?>">Manage User</a>
        <a href="manage-bahasa.php" class="nav-item <?= ($current_page == 'manage-bahasa.php') ? 'active' : '' ?>">Manage Bahasa</a>
        <a href="manage-kursus.php" class="nav-item <?= ($current_page == 'manage-kursus.php') ? 'active' : '' ?>">Manage Kursus</a>
        <a href="manage-materi.php" class="nav-item <?= ($current_page == 'manage-materi.php') ? 'active' : '' ?>">Manage Materi</a>
        <a href="transaksi.php" class="nav-item <?= ($current_page == 'transaksi.php') ? 'active' : '' ?>">Transaksi</a>
    </nav>
</aside>