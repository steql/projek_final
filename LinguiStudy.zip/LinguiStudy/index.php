<?php
header("Location: Member_page/Dashboard.php");
?>