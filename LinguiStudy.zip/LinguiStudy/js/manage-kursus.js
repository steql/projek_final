function filterLanguage(element, lang) {
    const rows = document.querySelectorAll('.course-row');
    const btns = document.querySelectorAll('.filter-wrapper .filter-btn');
    
    btns.forEach(btn => btn.classList.remove('active'));
    element.classList.add('active');
    
    rows.forEach(row => {
        const rowLang = row.getAttribute('data-language');
        if (lang === 'all' || rowLang === lang) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

function openModal() {
    const modal = document.getElementById('addCourseModal');
    if(modal) modal.style.display = 'flex';
}

function closeModal() {
    const modal = document.getElementById('addCourseModal');
    if(modal) modal.style.display = 'none';
}

window.onclick = function(event) {
    const modal = document.getElementById('addCourseModal');
    if (event.target == modal) {
        closeModal();
    }
}