document.addEventListener('DOMContentLoaded', function() {
    if (typeof AOS !== 'undefined') {
        AOS.init({ once: true, duration: 800 });
    }

    window.showTab = function(tabId) {
        const contents = document.querySelectorAll('.tab-content');
        const buttons = document.querySelectorAll('.nav-btn');
        
        contents.forEach(content => content.classList.remove('active'));
        buttons.forEach(btn => btn.classList.remove('active'));

        const targetTab = document.getElementById(tabId);
        if(targetTab) {
            targetTab.classList.add('active');
        }
        
        if (event && event.currentTarget) {
            event.currentTarget.classList.add('active');
        }
    };

    const alert = document.querySelector('.alert');
    if (alert) {
        setTimeout(() => {
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-10px)';
            alert.style.transition = '0.5s ease';
            setTimeout(() => alert.remove(), 4000);
        }, 4000);
    }
});