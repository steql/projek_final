document.addEventListener("DOMContentLoaded", () => {
    AOS.init({
        once: true,
        offset: 60,
        duration: 800,
        easing: "ease-out-cubic"
    })

    const page = document.getElementById("page")
    const cards = document.querySelectorAll(".language-card")

    cards.forEach(card => {
        card.addEventListener("click", e => {
            e.preventDefault()
            const url = card.getAttribute("data-url")
            page.classList.add("page-out")
            setTimeout(() => {
                window.location.href = url
            }, 400)
        })
    })
})
