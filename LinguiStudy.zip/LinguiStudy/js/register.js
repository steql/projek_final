function validateRegister() {
    var username = document.getElementById("username").value.trim();
    var email = document.getElementById("email").value.trim();
    var password = document.getElementById("password").value.trim();
    var confirm = document.getElementById("confirm").value.trim();
    var terms = document.getElementById("terms").checked;

    if (username.length < 5 || username.length > 20) {
        alert("Username harus 5 sampai 20 karakter");
        return false;
    }

    if (email.indexOf("@gmail.com") === -1) {
        alert("Email harus menggunakan gmail.com");
        return false;
    }

    if (password.length < 5) {
        alert("Password minimal 5 karakter");
        return false;
    }

    if (password !== confirm) {
        alert("Password dan konfirmasi tidak sama");
        return false;
    }

    if (!terms) {
        alert("Setujui terms and conditions");
        return false;
    }

    return true;
}
