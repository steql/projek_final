function validateLogin() {
    var email = document.getElementById("email").value.trim();
    var password = document.getElementById("password").value.trim();

    if (email === "") {
        alert("Email wajib diisi");
        return false;
    }

    if (email.indexOf("@") === -1 || email.indexOf(".") === -1) {
        alert("Format email tidak valid");
        return false;
    }

    if (password === "") {
        alert("Password wajib diisi");
        return false;
    }

    return true;
}
