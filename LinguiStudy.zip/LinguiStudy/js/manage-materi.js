function loadKursus() {
    const bId = document.getElementById('sel_bahasa').value;
    const kSelect = document.getElementById('sel_kursus');
    kSelect.innerHTML = '<option value="">Select Course</option>';
    
    if(bId) {
        const filtered = kursusList.filter(k => k.bahasa_id == bId);
        filtered.forEach(k => {
            const opt = document.createElement('option');
            opt.value = k.kursus_id;
            opt.textContent = k.judul;
            kSelect.appendChild(opt);
        });
        kSelect.disabled = false;
    } else {
        kSelect.disabled = true;
    }
}

function filterByCourse(cName, el) {
    const isActive = el.classList.contains('active-filter');
    document.querySelectorAll('.stat-card').forEach(c => c.classList.remove('active-filter'));
    const rows = document.querySelectorAll('#materiBody .course-row');

    if (isActive) {
        rows.forEach(r => r.style.display = "");
    } else {
        el.classList.add('active-filter');
        rows.forEach(r => {
            r.style.display = (r.getAttribute('data-course') === cName) ? "" : "none";
        });
    }
}

function openModal() {
    document.getElementById('addMateriModal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('addMateriModal').style.display = 'none';
}