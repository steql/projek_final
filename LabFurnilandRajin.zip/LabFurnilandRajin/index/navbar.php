
<link rel="stylesheet" href="../assets/css/navbar.css">
<nav id="nav-container">
    <div id="nav-left">
        <a href="../Member_page/Home-quest.php" class="logo">Furniland</a>

        <?php if (!isset($_SESSION['current_role'])): ?>
        <a href="Home-quest.php">Home</a>

        <?php elseif ($_SESSION['current_role'] == 'member'): ?>
        <a href="../Member_page/Home-quest.php">Home</a>
        <a href="../Member_page/catalog.php">Catalog</a>

        <?php elseif ($_SESSION['current_role'] == 'admin'): ?>
        <a href="../admin-page/dashboard.php">Dashboard</a>

        <?php endif; ?>
    </div>

    <div id="nav-right">
        <?php if (!isset($_SESSION['login_user'])): ?>
            <a href="../Member_page/login.php" class="login-btn">Login</a>

        <?php else: ?>
            <a href="../Member_page/profile.php" class="user-box">Hello, <?= htmlspecialchars($_SESSION['login_user']) ?></a>

            <?php if ($_SESSION['current_role'] == 'member'): ?>
                <a href="../Member_page/cart.php" class="userbx">Cart</a>
                <a href="../Member_page/history.php" class="userbx">History</a>
            <?php endif; ?>

            <a href="../index/logout.php" class="logout-btn">Logout</a>
        <?php endif; ?>
    </div>
</nav>
