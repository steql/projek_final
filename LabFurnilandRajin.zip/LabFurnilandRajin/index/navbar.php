
<link rel="stylesheet" href="../assets/css/navbar.css">
<nav id="nav-container">
    <div id="nav-left">
        <a href="Home-quest.php" class="logo">Furniland</a>

        <?php if (!isset($_SESSION['current_role'])): ?>
            <a href="Home-quest.php">Home</a>

        <?php elseif ($_SESSION['current_role'] == 'admin'): ?>
            <a href="Home-quest.php">Home</a>
            <a href="Catalog.php">Catalog</a>

        <?php elseif ($_SESSION['current_role'] == 'member'): ?>

            <a href="Dashboard.php">Dashboard</a>

        <?php endif; ?>
    </div>

    <div id="nav-right">
        <?php if (!isset($_SESSION['login_user'])): ?>
            <a href="../Member_page/login.php" class="login-btn">Login</a>

        <?php else: ?>
            <span class="user-box">
                Hello, <?= htmlspecialchars($_SESSION['login_user']) ?>
            </span>

            <?php if ($_SESSION['current_role'] == 'admin'): ?>
                <a href="Cart.php">Cart</a>
                <a href="History.php">History</a>
            <?php endif; ?>

            <a href="../index/logout.php" class="logout-btn">Logout</a>
        <?php endif; ?>
    </div>
</nav>
