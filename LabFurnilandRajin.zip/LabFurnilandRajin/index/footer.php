<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contoh Footer Mandiri</title>
    <link rel="stylesheet" href="../assets/css/footer.css">
</head>
<body>
    <footer>
        <span class="footer-top">@2025 Furniland All right reserved <br>Contact us at </span><span class="footer-bot">furniland.support@gmail.com</span><br>
    </footer>

</body>
</html>