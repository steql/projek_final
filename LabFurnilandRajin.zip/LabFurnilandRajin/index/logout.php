<?php
    session_start();
    session_destroy();
    header("location:../Member_page/Home-quest.php");
    exit();
?>