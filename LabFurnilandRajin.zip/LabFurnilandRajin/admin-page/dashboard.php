<?php 
include ('../index/index.php');  
include ('../index/navbar.php');

$current_id = $_SESSION['user_id'] ?? 0;
$adminName = "Admin"; 

$query = "SELECT username, role FROM users WHERE userID = '$current_id'";
$result = mysqli_query($conn, $query);

$is_admin = false;
$adminName ="Admin";

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $adminName = $row['username'];
    
    if ($row['role'] === 'admin') {
        $is_admin = true;
    }
}

if (!$is_admin) {
    header("Location: ../Member_page/login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Furniland - Admin Dashboard</title>
  <link rel="stylesheet" href="../assets/css//adminpage/dashboard.css" />
</head>
<body>
  

  <main>
    <div class="main-section">
    <h1 class="page-title">Admin Dashboard</h1>
    <div class="dashboard-grid">
      <a class="dashboard-card" href="manage-users.php">
        <h3>Manage Users</h3>
        <p>View and remove users.</p>
      </a>

      <a class="dashboard-card" href="manage-vendors.php">
        <h3>Manage Vendors</h3>
        <p>View, add, edit, and delete vendors.</p>
      </a>

      <a class="dashboard-card" href="manage-product.php">
        <h3>Manage Products</h3>
        <p>Manage product listings and details.</p>
      </a>

      <a class="dashboard-card" href="manage-transaction.php">
        <h3>Manage Transactions</h3>
        <p>View completed transactions.</p>
      </a>
    </div>
    <div class="welcome-section">
      <h1>Welcome, <?= htmlspecialchars($_SESSION['login_user']) ?>!</h1>
      <p>Use the cards above to manage the platform. Keep track of users, inventory, vendors, and transactions efficiently.</p>
    </div>
  </div>
  </main>
  

<?php
include('../index/footer.php');
?>
</body>
</html>
