<?php 
include ('../index/index.php');  
include ('../index/navbar.php');
$alert_message = "";
$alert_type = ""; 

if (isset($_GET['delete'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete']);
    $delete_products_query = "DELETE FROM products WHERE vendorId = '$id'";
    mysqli_query($conn, $delete_products_query); 
    $delete_vendor_query = "DELETE FROM vendor WHERE vendorId = '$id'";
    
    if(mysqli_query($conn, $delete_vendor_query)) {
        header("Location: manage-vendors.php?msg=deleted");
        exit();
    } else {
        $alert_message = "Error deleting vendor: " . mysqli_error($conn);
        $alert_type = "error";
    }
}

$query = "SELECT * FROM vendor";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Furniland - Manage Vendors</title>
  <link rel="stylesheet" href="../assets/css/adminpage/managevendor.css" />
</head>
<body>
  <main>
    <div class="header-container">
      <h1 class="page-title">Manage Vendors</h1>
      <a href="../admin-page/add-vendor.php" class="btn-add">+ Add Vendor</a>
    </div>

    <div class="table-wrapper">
      <table>
        <thead>
          <tr>
            <th>Vendor Name</th>
            <th>Location</th>
            <th>Actions</th>
          </tr>
        </thead>
          <tbody>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
            <tr>
              <td><?= htmlspecialchars($row['vendorName']) ?></td>
              <td><?= htmlspecialchars($row['location']) ?></td>
              <td>
                <form action="edit-vendor.php" method="POST">
                  <input type="hidden" name="vendor_id_to_edit" value="<?= $row['vendorID'] ?>">
                  <button type="submit" class="btn-edit">Edit</button>
                </form>
                  <a href="manage-vendors.php?delete=<?= $row['vendorID'] ?>" class="btn-delete" onclick="return confirm('Are you sure you want to delete this vendor?');">Delete</a>
              </td>
            </tr>
              <?php endwhile; ?>
              <?php if(mysqli_num_rows($result) == 0): ?>
            <tr>
              <td colspan="3" style="text-align:center;">No vendors found.</td>
            </tr>
            <?php endif; ?>
          </tbody>
      </table>
    </div>
  </main>

<?php
include('../index/footer.php');
?>
</body>
</html>
