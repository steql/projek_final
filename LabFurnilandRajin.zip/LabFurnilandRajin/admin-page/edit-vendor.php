<?php 
include ('../index/index.php');  
include ('../index/navbar.php');

$id = "";

if (isset($_POST['vendor_id_to_edit'])) {
    $id = mysqli_real_escape_string($conn, $_POST['vendor_id_to_edit']);
    $_SESSION['current_editing_vendor'] = $id; 
} 
elseif (isset($_SESSION['current_editing_vendor'])) {
    $id = $_SESSION['current_editing_vendor'];
} 
else {
    header("Location: manage-vendors.php");
    exit();
}

$error_msg = "";

$query = "SELECT * FROM vendor WHERE vendorID = '$id'";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    echo "Vendor not found!";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_vendor'])) {
    $vendorName = mysqli_real_escape_string($conn, $_POST['vendorName']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);

    if (empty($vendorName) || empty($location)) {
        $error_msg = "All fields are required!";
    }  elseif (strlen($vendorName) > 20) {
        $error_msg = "Vendor name maximum 20 characters!";
    }elseif (strlen($location) > 100) {
        $error_msg = "Location maximum characters!";
    }
     if (empty($error_msg)) {
        $update_query = "UPDATE vendor SET vendorName='$vendorName', location='$location' WHERE vendorID='$id'";

        if (mysqli_query($conn, $update_query)) {
            unset($_SESSION['current_editing_vendor']);
            header("Location: manage-vendors.php");
            exit(); 
        } else {
            $error_msg = "Error updating vendor: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Furniland - Edit Vendors</title>
    <link rel="stylesheet" href="../assets/css/editvendor.css">
</head>
<body>
    <main>
        <div class="form-container">
        <h2 class="page-title" >Edit Vendor</h2>
        <?php if (!empty($error_msg)): ?>
                <div class="error-message">
                    <?= htmlspecialchars($error_msg) ?>
                </div>
            <?php endif; ?>
            <form action="" method="POST">
                <div class="form-group">
                    <label>Vendor Name</label>
                    <input type="text" name="vendorName" value="<?= htmlspecialchars($data['vendorName']) ?>" required>
                </div>

                <div class="form-group">
                    <label>Location</label>
                    <input type="text" name="location" value="<?= htmlspecialchars($data['location']) ?>" required>
                </div>

                <div class="form-group" >
                    <button type="submit" class="btn-submit" name="update_vendor">Update Vendor</button>
                </div>
            </form>
        </div>
    </main>
<?php
include('../index/footer.php');
?>
</body>
</html>