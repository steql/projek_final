<?php 
include ('../index/index.php'); 
include ('../index/navbar.php'); 

$alert_message="";
$alert_type="";

if (isset($_GET['delete'])) {
    $id_to_delete = mysqli_real_escape_string($conn, $_GET['delete']);
    $delete_query = "DELETE FROM products WHERE productID = '$id_to_delete'";

    if(mysqli_query($conn, $delete_query)) {
        header("Location: manage-product.php?msg=deleted");
        exit();
    } else {
        $alert_message = "Error deleting products: " . mysqli_error($conn);
        $alert_type = "error";
    }
}
$vendor_query = "SELECT vendorID, vendorName FROM vendor";
$vendors = mysqli_query($conn, $vendor_query);
$vendorFilter = $_GET['vendor'] ?? "";

$where = "";
if (!empty($vendorFilter)) {
    $safeVendor = mysqli_real_escape_string($conn, $vendorFilter);
    $where = "WHERE p.vendorID = '$safeVendor'";
}

$query = "SELECT p.*, v.vendorName FROM products p JOIN vendor v ON p.vendorID = v.vendorID $where ORDER BY p.productID DESC
";

$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Furniland - Manage Products</title>
  <link rel="stylesheet" href="../assets/css/adminpage/manageproduct.css"/>
</head>
<body>
  <main>
    <div class="header-container">
      <h1 class="page-title">Manage Products</h1>
      <a href="add-product.php" class="btn-add">+ Add Product</a>
    </div>

    <div class="top-controls">
      <form action="manage-product.php" method="GET" class="filter-group">
          <select name="vendor" class="vendor-select" onchange="this.form.submit()">
            <option value="">All Vendors</option>
            <?php if (mysqli_num_rows($vendors) > 0): ?>
            <?php 
            mysqli_data_seek($vendors, 0); 
            while ($v = mysqli_fetch_assoc($vendors)): 
            ?>
            <option value="<?= $v['vendorID'] ?>"
              <?= ($vendorFilter == $v['vendorID']) ? 'selected' : '' ?>>
              <?= htmlspecialchars($v['vendorName']) ?>
            </option>
            <?php endwhile; ?>
            <?php endif; ?>
          </select>
        </form>
    </div>

    <div class="table-wrapper">
      <table>
        <thead>
          <tr>
            <th class="col-img">Image</th>
            <th class="col-id">ID</th>
            <th class="col-name">Name</th>
            <th class="col-price">Price</th>
            <th class="col-vendor">Vendor</th>
            <th class="col-action">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if(mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)) : ?>
              <tr>
                <td>
                  <?php if(!empty($row['image'])): ?>
                      <img src="<?= htmlspecialchars($row['image']) ?>" alt="Img" class="product-thumbnail">
                  <?php else: ?>
                      <span class="no-img">No Img</span>
                  <?php endif; ?>
                </td>
                  
                <td><?= htmlspecialchars($row['productID']) ?></td>
                <td><strong><?= htmlspecialchars($row['productName']) ?></strong></td>    
                <td>Rp <?= number_format($row['price'], 0, ',', '.') ?></td>
                <td><?= htmlspecialchars($row['vendorName']) ?></td>  

                <td>
                  <div class="action-links">
                    <a href="edit-product.php?id=<?= $row['productID'] ?>" class="action-edit">Edit</a>
                    <a href="./manage-product.php?delete=<?= $row['productID'] ?>" class="action-delete" onclick="return confirm('Are you sure you want to delete this product?');">
                    Delete
                    </a>
                  </div>
                </td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
              <tr>
                <td colspan="6" class="section-title">No products found based on your criteria.
                </td>
              </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>


<?php
include('../index/footer.php');
?>
</body>
</html>