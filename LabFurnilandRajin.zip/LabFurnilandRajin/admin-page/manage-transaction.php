<?php 
include ('../index/index.php');  
include ('../index/navbar.php');
$transaction_data = [];

$query = "SELECT transactionID, userID, totalPrice, transactionDate FROM transactions ORDER BY transactionDate DESC";
$result = mysqli_query($conn, $query); 

if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $user_id = $row['userID'];

        $user_query = "SELECT username FROM users WHERE userID = '$user_id'";
        $user_result = mysqli_query($conn, $user_query);
        $username = mysqli_fetch_assoc($user_result)['username'] ?? 'N/A';
        
        $transaction_data[] = [
            'id' => $row['transactionID'],
            'user' => $username,
            'price' => $row['totalPrice'],
            'date' => $row['transactionDate']
        ];
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Furniland - Manage Transactions</title>
  <link rel="stylesheet" href="../assets/css/adminpage/managetransaction.css" />
</head>
<body>
  <main class="transaction-page">
    <h1 class="page-title">All Transactions</h1>
      <?php if (!empty($transaction_data)): ?>
      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Transaction ID</th>
              <th>User</th>
              <th>Total Price</th>
              <th>Date</th>
            </tr>
            </thead>
              <tbody>
                <?php foreach ($transaction_data as $trans): ?>
                <tr>
                  <td>#<?= htmlspecialchars($trans['id']) ?></td>
                  <td><?= htmlspecialchars($trans['user']) ?></td>
                  <td>Rp <?= number_format($trans['price'], 0, ',', '.') ?></td>
                  <td><?= date('d M Y', strtotime($trans['date'])) ?></td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
      </div>
        <?php else: ?>
        <p class="section-title">No transactions found.</p>
        <?php endif; ?>
    </main>
<?php
include('../index/footer.php');
?>
</body>
</html>
