<?php 
include ('../index/index.php'); 
include ('../index/navbar.php'); 

$vendor_query = "SELECT * FROM vendor";
$vendor_result = mysqli_query($conn, $vendor_query);

$name = "";
$desc = "";
$price = "";
$vendorID = "";
$error_msg = "";

if (isset($_POST['add_product'])) {
    
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $desc = mysqli_real_escape_string($conn, $_POST['description']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $vendorID = mysqli_real_escape_string($conn, $_POST['vendor']);
    
    if (empty($name)) {
        $error_msg = "Product Name must be filled.";
    } elseif (strlen($name) < 3 || strlen($name) > 30) {
        $error_msg = "Product Name must be between 3 and 30 characters.";
    }
    
    elseif (empty($desc)) {
        $error_msg = "Description must be filled.";
    }
    
    elseif (empty($price)) {
        $error_msg = "Price must be filled.";
    } elseif (!is_numeric($price) || $price <= 0) {
        $error_msg = "Price must be a number greater than 0.";
    }
    
    elseif (empty($vendorID)) {
        $error_msg = "You must choose a vendor.";
    }
    
    elseif (empty($_FILES["image"]["name"])) {
        $error_msg = "Product Image must be uploaded.";
    } else {
        $filename = basename($_FILES["image"]["name"]);
        $imageFileType = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png']; 
        
        if (!in_array($imageFileType, $allowed_extensions)) {
            $error_msg = "Invalid image format! Only .jpg and .png are allowed.";
        }
    }

    if (empty($error_msg)) {
        $target_dir = "../img/";
        $new_filename = time() . "_" . $filename; 
        $target_file = $target_dir . $new_filename;
        
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            
            $db_image_path = "../img/" . $new_filename;
            
            $query = "INSERT INTO products (productName, description, price, vendorID, image) VALUES ('$name', '$desc', '$price', '$vendorID', '$db_image_path')";
            
            if (mysqli_query($conn, $query)) {
                header("Location:./manage-product.php");
                exit();
            } else {
                $error_msg = "Database Error: " . mysqli_error($conn);
            }
        } else {
            $error_msg = "Failed to upload image to server.";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Furniland - Add Product</title>
    <link rel="stylesheet" href="../assets/css/addproduct.css">
</head>
<body>
<main class="form-container">
    <div class="form-card">
        <h2 class="form-title">Add New Product</h2>

        <?php if (!empty($error_msg)): ?>
        <div class="error-message">
            <?= htmlspecialchars($error_msg) ?>
        </div>
        <?php endif; ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Product Name</label>
                <input type="text" id="name" name="name" required >
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" rows="3"  required></textarea>
            </div>

            <div class="form-group">
                <label for="price">Price</label>
                <input type="number" id="price" name="price" >
            </div>

            <div class="form-group">
                <label for="vendor">Vendor</label>
                <select id="vendor" name="vendor" required>
                    <option value="">Select Vendor</option>
                    <?php 
                    if (mysqli_num_rows($vendor_result) > 0) {
                        mysqli_data_seek($vendor_result, 0);
                        while($v = mysqli_fetch_assoc($vendor_result)): 
                    ?>
                    <option value="<?= $v['vendorID'] ?>"><?= htmlspecialchars($v['vendorName']) ?></option>
                    <?php 
                        endwhile; 
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="image">Product Image</label>
                <input type="file" id="image" name="image" required accept="image/*">
            </div>
            <button type="submit" name="add_product" class="btn-submit">Add Product</button>
        </form>
    </div>
</main>
<?php include('../index/footer.php'); ?>

</body>
</html>