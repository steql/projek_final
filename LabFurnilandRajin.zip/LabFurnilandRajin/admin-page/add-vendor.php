<?php 
include ('../index/index.php');  
include ('../index/navbar.php');

$error_msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_vendor'])) {
    $vendorName = mysqli_real_escape_string($conn, $_POST['vendorName']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);

    if (empty($vendorName) || empty($location)) {
        $error_msg = "All fields are required!";
    } elseif (strlen($vendorName) > 20) {
        $error_msg = "Vendor name must not exceed 20 characters.";
    } elseif (strlen($location) > 100) {
        $error_msg = "Location must not exceed 100 characters.";
    } else {

    $insert_query = "INSERT INTO vendor (vendorName, location) VALUES ('$vendorName', '$location')";

    if (mysqli_query($conn, $insert_query)) {
        header("Location: manage-vendors.php");
        exit();
        } else {
            $error_msg = "Error adding vendor: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Furniland - Edit Vendors</title>
    <link rel="stylesheet" href="../assets/css/addvendor.css">
</head>
<body>
    <main>
        <div class="form-container">
        <h2 class="page-title" >Add Vendor</h2>

        <?php if (!empty($error_msg)): ?>
                <div class="error-box">
                    <?= htmlspecialchars($error_msg) ?>
                </div>
            <?php endif; ?>

            <form action="" method="POST">
                <div class="form-group">
                    <label>Vendor Name</label>
                    <input type="text" name="vendorName" >
                </div>

                <div class="form-group">
                    <label>Location</label>
                    <input type="text" name="location" >
                </div>

                <div class="form-group">
                    <button type="submit" class="btn-submit" name="add_vendor">Add Vendor</button>
                </div>
            </form>
        </div>
    </main>
<?php
include('../index/footer.php');
?>
</body>
</html>