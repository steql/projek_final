<?php 
include ('../index/index.php');  
include ('../index/navbar.php');

if (isset($_GET['delete'])) {
    $id_to_delete = $_GET['delete'];
    
    if ($id_to_delete != $_SESSION['user_id']) {
      $delete_query = "DELETE FROM users WHERE userID = '$id_to_delete'";
      mysqli_query($conn, $delete_query);
    }
    header("Location: manage-users.php");
    exit();
}

$query = "SELECT * FROM users";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Furniland - Manage Users</title>
  <link rel="stylesheet" href="../assets/css/adminpage/manageuser.css" />
</head>
<body>

  <main>
    <h1 class="page-title">Manage Users</h1>
    <div class="table-wrapper">
      <table>
        <thead>
          <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Gender</th>
            <th>Date of Birth</th>
            <th>Role</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = mysqli_fetch_assoc($result)) : ?>
            <tr>
              <td><?= htmlspecialchars($row['username']) ?></td>
              <td><?= htmlspecialchars($row['email']) ?></td>
              <td><?= htmlspecialchars($row['gender']) ?></td>
              <td><?= htmlspecialchars($row['dob']) ?></td>
              <td><?= htmlspecialchars($row['role']) ?></td>
              <td>
              <?php if ($row['role'] === 'admin') : ?>
                  <span class="badge-admin">Current Admin</span>
              <?php else : ?>
                  <a href="manage-users.php?delete=<?= $row['userID'] ?>" 
                    class="btn-delete" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
              <?php endif; ?>
              </td>
            </tr>
        <?php endwhile; ?>
        <?php if(mysqli_num_rows($result) == 0): ?>
          <tr>
            <td colspan="6" style="text-align:center;">No users found.</td>
          </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>

<?php
include('../index/footer.php');
?>
</body>
</html>
