const errMsg = document.getElementById("register-error");

function onButtonClicked(e) {
  e.preventdefault();
  const username = document.getElementById("reg-username").value;
  const email = document.getElementById("reg-email").value;
  const password = document.getElementById("reg-password").value;
  const confirm = document.getElementById("reg-confirm").value;
  const malecheck = document.getElementById("reg-male").checked;
  const femalecheck = document.getElementById("reg-female").checked;
  const dob = document.getElementById("reg-dob").value;

    if(username === "" || email === "" || password === "" || confirm === "" ){
    showError("Must not be Empty");
    return;
    }

    if(username.length < 4 || username.length > 20){
    showError("Username must be 4 - 20 characters.");
    return;
    }

    if(!email.endsWith("@gmail.com")) {
    showError("Email must end with @gmail.com.");
    return;
    }

    if(password.length < 8) {
    showError("Password must be at least 8 characters.");
    return;
    }

    if(confirm !== password) {
    showError("Confirm password must match.");
    return;
    }

    if(!malecheck && !femalecheck){
    showError("Gender option must be selected");
    return;
    }

  if (!dob || !isPastDate(dob)) {
    showError("Date of Birth must be a valid date in the past.");
    return;
  }

    showError("");
}

function isPastDate(date) {
  const input = new Date(date);
  const today = new Date();
  return input < today;
}


function showError(message) {
  errMsg.innerText = message;
}

document
  .getElementById("btn")
  .addEventListener("click", onButtonClicked);

