const errMsg = document.getElementById("register-error");

function onButtonClicked(e) {
  const username = document.getElementById("reg-username").value;
  const email = document.getElementById("reg-email").value;
  const password = document.getElementById("reg-password").value;
  const confirm = document.getElementById("reg-confirm").value;
  const malecheck = document.getElementById("reg-male").checked;
  const femalecheck = document.getElementById("reg-female").checked;
  const dob = document.getElementById("reg-dob").value;

  if (username === "" || email === "" || password === "" || confirm === "") {
    e.preventDefault(); 
    showError("All fields must be filled.");
    return;
  }

  if (username.length < 4 || username.length > 20) {
    e.preventDefault(); 
    showError("Username must be between 4 and 20 characters.");
    return;
  }

  if (!email.endsWith("@gmail.com")) {
    e.preventDefault();
    showError("Email must end with '@gmail.com'.");
    return;
  }

  if (password.length < 8) {
    e.preventDefault();
    showError("Password must be at least 8 characters.");
    return;
  }

  if (confirm !== password) {
    e.preventDefault(); 
    showError("Confirm password does not match.");
    return;
  }

  if (!malecheck && !femalecheck) {
    e.preventDefault(); 
    showError("Gender must be selected.");
    return;
  }

  if (!dob || !isPastDate(dob)) {
    e.preventDefault(); 
    showError("Date of Birth must be in the past.");
    return;
  }

}

function isPastDate(date) {
  const input = new Date(date);
  const today = new Date();
  today.setHours(0, 0, 0, 0); 
  return input < today;
}

function showError(message) {
  errMsg.innerText = message;
}

document
  .getElementById("btn")
  .addEventListener("click", onButtonClicked);