const errMsg = document.getElementById("login-error");

function onButtonClicked(e) {
  e.preventDefault();
    const email = document.getElementById("login-email").value;
    const password = document.getElementById("login-password").value;
    const remember = document.getElementById("login-remember").checked;

    if(email === "" || password === "" ){
    showError("Email and password must not be empty!");
    return;
    }
  showError("");
}


function showError(message) {
  errMsg.innerText = message;
}

document
  .getElementById("btn")
  .addEventListener("submit", onButtonClicked);

