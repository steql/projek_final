<?php
include ('../index/index.php');
include ('../index/navbar.php');

$user_id = $_SESSION['user_id'];
$history_data = [];

$history_query = "SELECT * FROM transactions WHERE userID = '$user_id' ORDER BY transactionDate DESC";
$history_result = mysqli_query($conn, $history_query);

if (mysqli_num_rows($history_result) > 0) {
    while ($trans = mysqli_fetch_assoc($history_result)) {
        $t_id = $trans['transactionID'];
        $detail_query = "SELECT d.*, p.productName FROM transaction_detail d JOIN products p ON d.productID = p.productID WHERE d.transactionID = '$t_id'";
        $detail_result = mysqli_query($conn, $detail_query);
        $items = [];
        while ($item = mysqli_fetch_assoc($detail_result)) {
            $items[] = $item;
        }
        $history_data[] = [
            'info' => $trans,
            'items' => $items
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Furniland - Transaction History</title>
    <link rel="stylesheet" href="../assets/css/memberpage/history.css" />
</head>
<body>
    <main>
        <h1 class="hero-text">Transaction History</h1>
        <?php if (!empty($history_data)) : ?>
        <?php foreach ($history_data as $data) : ?>
          <div class="transaction-card">
            <div class="card-header-info">
              <div class="left-info">
                <span class="trans-id">Transaction ID: <?=$data['info']['transactionID'] ?></span>
                <span class="trans-date">Date: <?= date('d M Y', strtotime($data['info']['transactionDate'])) ?></span>
              </div>
                <div class="right-info">
                  <span class="total-amount"> Total : Rp <?= number_format($data['info']['totalPrice'], 0, ',', '.') ?></span>
                </div>
            </div>

            <div class="table-wrapper">
              <table>
                  <thead>
                    <tr>
                      <th>Product</th>
                      <th>Qty</th>
                      <th>Subtotal</th>
                    </tr>
                  </thead>
                    <tbody>
                      <?php foreach ($data['items'] as $item) :
                      ?>
                        <tr>
                          <td><?= htmlspecialchars($item['productName']) ?></td>
                          <td><?= htmlspecialchars($item['quantity']) ?></td>
                          <td>Rp <?= number_format($item['subtotal'], 0, ',', '.') ?></td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
              </table>
            </div>
          </div>
            <?php endforeach; ?>
        <?php else : ?>
          <div class="section-title">
            <p>You have no transaction history yet.</p>
          </div>
        <?php endif; ?>
    </main>

<?php
include ('../index/footer.php');
?>

</body>
</html>