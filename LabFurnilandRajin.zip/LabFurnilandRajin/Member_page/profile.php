<?php
include ('../index/index.php');
include ('../index/navbar.php');

$user_id = $_SESSION['user_id'] ?? 0;
$alert_script = "";


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $dob = mysqli_real_escape_string($conn, $_POST['dob']);

    if (empty($username) || empty($email) || empty($gender) || empty($dob)) {
        $alert_script = "All fields must be filled.";
    } elseif (strlen($username) < 4 || strlen($username) > 20) {
        $alert_script = "Username must be 4 - 20 characters.";
    }
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $alert_script = "Invalid email format.";
    } else {
        $update_query = "UPDATE users SET username='$username', email='$email', gender='$gender', dob='$dob' WHERE userID='$user_id'";
        if (mysqli_query($conn, $update_query)) {
            $_SESSION['login_user'] = $username;
            $alert_script = "Profile updated successfully!";
        } else {
            $alert_script = "Failed to update profile.";
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_password'])) {
    $current_pass = $_POST['current_password'];
    $new_pass = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];

    $check = mysqli_query($conn, "SELECT password FROM users WHERE userID='$user_id'");
    $data = mysqli_fetch_assoc($check);

    if (empty($current_pass) || empty($new_pass) || empty($confirm_pass)) {
        $alert_script = "All fields must be filled.";
    } elseif ($current_pass != $data['password']) {
        $alert_script = "Current password is incorrect.";
    } elseif (strlen($new_pass) < 6) {
        $alert_script = "New password must be at least 6 characters.";
    } elseif ($new_pass !== $confirm_pass) {
        $alert_script = "New password and confirmation do not match.";
    } else {
        mysqli_query($conn, "UPDATE users SET password='$new_pass' WHERE userID='$user_id'");
        $alert_script = "Password updated successfully!";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_account'])) {
    $conf_pass = $_POST['delete_password'];

    $check = mysqli_query($conn, "SELECT password FROM users WHERE userID='$user_id'");
    $data = mysqli_fetch_assoc($check);

    if (empty($conf_pass)) {
        $alert_script = "Password must not be empty.";
    } elseif ($conf_pass != $data['password']) {
        $alert_script = "Incorrect password. Account deletion failed.";
    } else {
        mysqli_query($conn, "DELETE FROM users WHERE userID='$user_id'");
        session_destroy();
        header("location:Home-quest.php");
        exit;
    }
}

$query = "SELECT * FROM users WHERE userID='$user_id'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Furniland - Profile</title>
    <link rel="stylesheet" href="../assets/css/memberpage/profile.css">
<body>
    <main>
<div id="top-section">
    <div class="profile-card">
    <h3>Update Profile Information</h3>
    <form method="POST" class="form-wrapper">

        <?php if (!empty($alert_script) && isset($_POST['update_profile'])): ?>
            <div class="error-message"><?= htmlspecialchars($alert_script) ?></div>
        <?php endif; ?>

        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
        </div>

        <div class="form-group">
            <label>Gender</label>
            <select name="gender">
                <option value="Male" <?= ($user['gender'] == 'Male') ? 'selected' : '' ?>>Male</option>
                <option value="Female" <?= ($user['gender'] == 'Female') ? 'selected' : '' ?>>Female</option>
            </select>
        </div>

        <div class="form-group">
            <label>Date of Birth</label>
            <input type="date" name="dob" value="<?= htmlspecialchars($user['dob']) ?>" required>
        </div>

        <button type="submit" name="update_profile" class="btn-update">Save Changes</button>
    </form>
    </div>


    <div class="profile-card">
    <h3>Update Password</h3>
    <form method="POST" class="form-wrapper2">

        <?php if (!empty($alert_script) && isset($_POST['update_password'])): ?>
            <div class="error-message"><?= htmlspecialchars($alert_script) ?></div>
        <?php endif; ?>

        <div class="form-group">
            <label>Current Password</label>
            <input type="password" name="current_password" required>
        </div>

        <div class="form-group">
            <label>New Password</label>
            <input type="password" name="new_password" required>
        </div>

        <div class="form-group">
            <label>Confirm New Password</label>
            <input type="password" name="confirm_password" required>
        </div>

        <button type="submit" name="update_password" class="btn-update">Update Password</button>
    </form>
    </div>

    <div class="profile-card">
    <h3>Delete Account</h3>
    <div class="danger-text">Once deleted, your account cannot be recovered.</div>

    <form method="POST" class="form-wrapper3">

        <?php if (!empty($alert_script) && isset($_POST['delete_account'])): ?>
            <div class="error-message"><?= htmlspecialchars($alert_script) ?></div>
        <?php endif; ?>

        <div class="form-group">
            <label>Confirm Password</label>
            <input type="password" name="delete_password" required>
        </div>

        <button type="submit" name="delete_account" class="btn-delete"
            onclick="return confirm('Are you sure you want to delete your account?');">
            Delete Account
        </button>
    </form>
    </div>
    </main>
    
</div>
<?php
include ('../index/footer.php');
?>

</body>
</html>