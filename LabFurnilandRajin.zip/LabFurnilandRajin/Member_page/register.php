<?php
include ('../index/index.php');   

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {

    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $gender = $_POST['reg-gender'] ?? "";
    $dob = $_POST['dob'];
    $role = "member";

    if (empty($username) || empty($email) || empty($password) || 
        empty($confirm_password) || empty($gender) || empty($dob)) {

        $_SESSION['register_error'] = "All fields are required!";
        header("Location: register.php");
        exit();
    }

    if ($password !== $confirm_password) {
        $_SESSION['register_error'] = "Passwords do not match!";
        header("Location: register.php");
        exit();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['register_error'] = "Invalid email!";
        header("Location: register.php");
        exit();
    }

    $check_query = "SELECT * FROM users WHERE username='$username' OR email='$email'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        $_SESSION['register_error'] = "Username or email already exists!";
        header("Location: register.php");
        exit();
    }

    $insert_query = "
        INSERT INTO users (username, email, password, gender, dob, role)
        VALUES ('$username', '$email', '$password', '$gender', '$dob', '$role')
    ";

    if (mysqli_query($conn, $insert_query)) {
        $_SESSION['register_success'] = "Registration successful!";
        header("Location: catalog.php");
        exit();
    } else {
        $_SESSION['register_error'] = "Registration failed: " . mysqli_error($conn);
        header("Location: register.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Furniland - Register</title>
  <link rel="stylesheet" href="../assets/css/register.css" />
</head>
<body>
  <nav id="nav-container">
    <div id="nav-logo">
      <a href="../Member_page/Home-quest.php" id="Furniland">Furniland</a>
      <a href="../Member_page/Home-quest.php" id="Home">Home</a>
    </div>
    <div id="menu">
      <a href="../Member_page/login.php" id="Login">Login</a>
    </div>
  </nav>


  <main>
    <div class="form-wrapper">
      <h1 class="form-title">Register</h1>

      <form id="register-form" action="" method="POST">
        <div class="input-container">
          <label for="reg-username">Username</label>
          <input type="text" id="reg-username" name="username" />
        </div>

        <div class="input-container">
          <label for="reg-email">Email</label>
          <input type="text" id="reg-email" name="email"/>
        </div>

        <div class="input-container">
          <label for="reg-password">Password</label>
          <input type="password" id="reg-password" name="password"/>
        </div>

        <div class="input-container">
          <label for="reg-confirm">Confirm Password</label>
          <input type="password" id="reg-confirm" name="confirm_password"/>
        </div>

        <div class="input-container">
          <label>Gender</label>
          <div class="check-area">
            <input type="radio" name="reg-gender" id="reg-male" value="Male" />
            <label for="reg-male">Male</label>
            <input type="radio" name="reg-gender" id="reg-female" value="Female" />
            <label for="reg-female">Female</label>
          </div>
        </div>

        <div class="input-container">
          <label for="reg-dob">Date of Birth</label>
          <input type="date" id="reg-dob" name="dob" />
        </div>

        <span id="register-error" class="error-msg"></span>
        <button type="submit" class="btn"  id="btn" name="register">
          Register
        </button>
        <span id="text-under-btn" name="register">Already have an account?<a href="../Member_page/login.php" id="link-login">Login Here</a></span>
      </form>
    </div>
  </main>

  <footer>
    <span class="footer-top">@2025 Furniland All right reserved <br>Contact us at </span><span class="footer-bot">furniland.support@gmail.com</span></br>
  </footer>

  <script src="../assets/register.js"></script>
</body>
</html>
