<?php
include ('../index/index.php');
include ('../index/navbar.php');

$user_id = $_SESSION['user_id'];

if (isset($_GET['remove'])) {
    $cart_id_to_remove = mysqli_real_escape_string($conn, $_GET['remove']);
    $delete_query = "DELETE FROM cart WHERE cartID = '$cart_id_to_remove'";
    mysqli_query($conn, $delete_query);
    header("Location: cart.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['checkout'])) {
    $cart_query = "SELECT c.productID, c.quantity, p.price FROM cart c JOIN products p ON c.productID = p.productID WHERE c.userID = '$user_id'";

    $cart_result = mysqli_query($conn, $cart_query);
    $total_price = 0;
    $cart_items = [];

    while ($row = mysqli_fetch_assoc($cart_result)) {
        $subtotal = $row['price'] * $row['quantity'];
        $total_price += $subtotal;
        $cart_items[] = [
            'productID' => $row['productID'],
            'quantity' => $row['quantity'],
            'subtotal' => $subtotal
        ];
    }

    if (!empty($cart_items)) {
        $date_now = date('Y-m-d');
        $trans_query = "INSERT INTO transactions (userID, totalPrice, transactionDate) VALUES ('$user_id', '$total_price', '$date_now')";
        mysqli_query($conn, $trans_query);

        $new_trans_id = mysqli_insert_id($conn);

        foreach ($cart_items as $item) {
            $pID = $item['productID'];
            $qty = $item['quantity'];
            $sub = $item['subtotal'];

            $detail_query = "INSERT INTO transaction_detail (transactionID, productID, quantity, subtotal) VALUES ('$new_trans_id', '$pID', '$qty', '$sub')";
            mysqli_query($conn, $detail_query);
        }

        mysqli_query($conn, "DELETE FROM cart WHERE userID = '$user_id'");
        header("Location: catalog.php?msg=checkout_success");
        exit();
    }
}

$query = "SELECT c.cartID, c.quantity, p.productName, p.price, p.image FROM cart c JOIN products p ON c.productID = p.productID WHERE c.userID = '$user_id'";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Furniland - Cart</title>
    <link rel="stylesheet" href="../assets/css/memberpage/cart.css" />
</head>
<body>
    <main>
        <div id="top-section">
            <h1 class="hero-text">Your Cart</h1>
        </div>
        <?php if (mysqli_num_rows($result) > 0) : ?>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Qty</th>
                        <th>Subtotal</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $total_cart_value = 0;
                    while ($row = mysqli_fetch_assoc($result)) :
                    $subtotal = $row['price'] * $row['quantity'];
                    $total_cart_value += $subtotal;
                    ?>
                    <tr>
                        <td><?= htmlspecialchars($row['productName']) ?></td>
                        <td><?= htmlspecialchars($row['quantity']) ?></td>
                        <td>Rp <?= number_format($subtotal, 0, ',', '.') ?></td>
                        <td><a href="cart.php?remove=<?= $row['cartID'] ?>"class="btn-remove" onclick="return confirm('Remove this item from cart?');"> Remove </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <div class="form-wrapper">
            <form method="POST" action="">
                <button type="submit" name="checkout" class="checkout-btn">Checkout</button>
            </form>

        <?php else : ?>
            <div class="section-title">
                Your cart is empty
            </div>
        <?php endif; ?>
        </div>
    </main>

<?php
include('../index/footer.php');
?>
</body>
</html>