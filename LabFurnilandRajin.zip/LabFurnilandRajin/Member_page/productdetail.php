<?php 
include ('../index/index.php');  
include ('../index/navbar.php');


$error = ""; 
if (!isset($_GET['id'])) {
    $error = "Product not found.";
}

$product_id = $_GET['id'];

$check_query = "SELECT * FROM products WHERE productID = '$product_id'";
$check_result = mysqli_query($conn, $query);
$check_product = mysqli_fetch_assoc($result);

if (!$check_product) {
    $error = "Product not found.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Furniland - Product Detail</title>
  <link rel="stylesheet" href="../assets/css/productdetaill.css" />
</head>
<body>
<div class="detail-page">
    <div class="detail-image">
        <img src="../assets/product_img/<?= htmlspecialchars($product['productImage']) ?>" alt="">
    </div>

    <div class="detail-info">
        <h2><?= htmlspecialchars($product['productName']) ?></h2>
        
        <span><?= nl2br(htmlspecialchars($product['productDesc'])) ?></span>

        <span class="price">Rp <?= number_format($product['productPrice'], 0, ',', '.') ?>
        </span>

        <span>Vendor: <?= htmlspecialchars($product['vendorName']) ?></span>

        <span>Location: <?= htmlspecialchars($product['vendorLocation']) ?></span>


        <?php
        if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["cart"])) {

        if (!isset($_SESSION['login_user'])) {
        header("Location: login.php");
        exit;
        }   
        header("Location: cart.php"); 
        exit;
     }
    ?>

        <form action="" method="POST">
            <label for="qty">Quantity:</label>
            <input type="number" id="qty" name="quantity" min="1" value="1">
            
            <button type="submit" name="cart">Add to Cart</button>
        </form>

    </div>
</div>
  <footer>
    @2025 Furniland All right reserved <br>Contact us at furniland.support@gmail.com </br>
  </footer>

  <script src="assets/js/main.js"></script>
</body>
</html>
