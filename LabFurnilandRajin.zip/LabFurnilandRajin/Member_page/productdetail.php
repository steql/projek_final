<?php
include ('../index/index.php');
include ('../index/navbar.php');

$text = "";
$product = null;

if (isset($_GET['id'])) {
    $product_id = mysqli_real_escape_string($conn, $_GET['id']);
    $query = "SELECT p.*, v.vendorName, v.location FROM products p JOIN vendor v ON p.vendorID = v.vendorID WHERE p.productID = '$product_id'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $product = mysqli_fetch_assoc($result);
        if (!$product) {
            $text = "Product not found (ID: $product_id).";
        }
    } else {
        $text = "Database Error.";
    }

} else {
    $text = "Product ID not specified.";
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["cart"])) {
    if (!isset($_SESSION['user_id'])) {
        header("Location:login.php");
        exit();
    }

    $user_id = $_SESSION['user_id'];

    if (isset($_GET['id'])) {
        $product_id_to_cart = mysqli_real_escape_string($conn, $_GET['id']);
        $quantity = (int)$_POST['quantity'];
        if ($quantity < 1) $quantity = 1;

        $check_cart = "SELECT * FROM cart WHERE userID = '$user_id' AND productID = '$product_id_to_cart'";
        $check_result = mysqli_query($conn, $check_cart);

        if (mysqli_num_rows($check_result) > 0) {
            $existing_cart = mysqli_fetch_assoc($check_result);
            $new_qty = $existing_cart['quantity'] + $quantity;
            $cart_id = $existing_cart['cartID'];
            $update_query = "UPDATE cart SET quantity = '$new_qty' WHERE cartID = '$cart_id'";
            mysqli_query($conn, $update_query);
        } else {
            $insert_query = "INSERT INTO cart (userID, productID, quantity) VALUES ('$user_id', '$product_id_to_cart', '$quantity')";
            mysqli_query($conn, $insert_query);
        }

        header("Location: cart.php");
        exit;
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Furniland - <?= htmlspecialchars($product['productName']) ?></title>
    <link rel="stylesheet" href="../assets/css/memberpage/productdetail.css" />
</head>
<body>
    <div class="detail-page">
        <?php if ($product): ?>
        <div class="detail-image">
            <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['productName']) ?>">
        </div>

        <div class="detail-info">
            <h2><?= htmlspecialchars($product['productName']) ?></h2>
            <span><?= nl2br(htmlspecialchars($product['description'])) ?></span>
            <span class="price">Rp <?= number_format($product['price'], 0, ',', '.') ?></span>
            <span>Vendor: <?= htmlspecialchars($product['vendorName']) ?></span>
            <span>Location: <?= htmlspecialchars($product['location']) ?></span>

            <form action="" method="POST" style="margin-top: 20px;">
                <label for="qty">Quantity:</label>
                <input type="number" id="qty" name="quantity" min="1" value="1" >

                <button type="submit" name="cart" class="product-actions" >Add to Cart</button>
            </form>
        </div>
        <?php else: ?>
            <div style="color: red; padding: 50px; text-align: center; width: 100%;">
                <h1>Error</h1>
                <p><?= $text ?></p>
            </div>
        <?php endif; ?>
    </div>

<?php
include ('../index/footer.php');
?>

</body>
</html>