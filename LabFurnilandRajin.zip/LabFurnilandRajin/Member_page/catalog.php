<?php 
include ('../index/index.php');  
include ('../index/navbar.php');


$vendorFilter = $_GET['vendor'] ?? "";
$sortFilter   = $_GET['sort'] ?? "";
$searchFilter = $_GET['search'] ?? "";
$vendor_query = "SELECT vendorId, vendorName FROM vendors";

$vendors = mysqli_query($conn, $vendor_query);
$check_query = "SELECT p.productId, p.productName, p.price, p.image, p.description, v.vendorName, v.vendorLocation FROM products p JOIN vendors v ON p.vendorId = v.vendorId";

$where = [];
if ($vendorFilter !== "") {
    $vendorFilter = mysqli_real_escape_string($conn, $vendorFilter);
    $where[] = "p.vendorId = '$vendorFilter'";
}

if ($searchFilter !== "") {
    $search = mysqli_real_escape_string($conn, $searchFilter);
    $where[] = "p.productName LIKE '%$search%'";
}

if (!empty($where)) {
    $check_query .= " WHERE ".implode(" AND ", $where);
}

if ($sortFilter == "price-asc") {
    $check_query .= " ORDER BY p.price ASC";
} elseif ($sortFilter == "price-desc") {
    $check_query .= " ORDER BY p.price DESC";
}

$check_result = mysqli_query($conn, $check_query);
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Furniland - Catalog</title>
  <link rel="stylesheet" href="../assets/css/catalog.css" />
</head>
<body>
  <main>
    <div id="top-section">
      <h1 class="hero-text">Product Catalog</h1>
      <span class="section-title">Browse, filter and sort furnitures</span>
    </div>
    <form method="GET" class="filter">
      <div class="filter-bar">
        <select name="vendor">
          <option value="">All Vendors</option>
          <?php while ($v = mysqli_fetch_assoc($vendors)) : ?>
          <option value="<?= $v['vendorId'] ?>" 
            <?= $vendorFilter == $v['vendorId'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($v['vendorName']) ?>
          </option>
          <?php endwhile; ?>
        </select>

        <select name="sort">
          <option value="">Sort by</option>
          <option value="price-asc" <?= $sortFilter == "price-asc" ? 'selected' : '' ?>>Price: Low - High</option>
          <option value="price-desc" <?= $sortFilter == "price-desc" ? 'selected' : '' ?>>Price: High - Low</option>
        </select>
      </div>

      <div class="filter-search">
        <input type="text" name="search" class="search-bar" 
        placeholder="Search product" value="<?= htmlspecialchars($searchFilter) ?>">
        <button class="product-actions">Apply</button>
      </div>
    </form>

    <div class="product-grid">
      <?php while ($row = mysqli_fetch_assoc($check_result)) : ?>
      <div class="product-card">
        <img src="<?= htmlspecialchars($row['image']) ?>" alt="Product Image">
        <div class="text-area">
          <div class="product-name"><?= htmlspecialchars($row['productName']) ?></div>
          <div class="product-desc"><?= htmlspecialchars($row['description']) ?></div>
          <div class="product-price">Rp <?= number_format($row['price'], 0, ',', '.') ?></div>
          <div class="vendor">Vendor: <?= htmlspecialchars($row['vendorName']) ?></div>
        </div>
        <button class="product-actions">
          <a href="../Member_page/productdetail.php?id=<?= $row['productId'] ?>">View Details</a>
        </button>
      </div>
      <?php endwhile; ?>
    </div>
  </main>

  <footer>
    <span class="footer-top">@2025 Furniland All right reserved <br>Contact us at </span>
    <span class="footer-bot">furniland.support@gmail.com</span>
  </footer>

</body>
</html>