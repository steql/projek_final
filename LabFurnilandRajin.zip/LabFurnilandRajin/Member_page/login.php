<?php
include ('../index/index.php');
include ('../index/navbar.php');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $remember = isset($_POST['remember']);

    if (empty($email) || empty($password)) {
        $_SESSION['login_error'] = "Email and password must not be empty!";
        header("Location: login.php");
        exit();
    }

    $check_query = "SELECT * FROM users WHERE email='$email'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) != 1) {
        $_SESSION['login_error'] = "Email not found!";
        header("Location: login.php");
        exit();
    }

    $row = mysqli_fetch_assoc($check_result);

    if ($password !== $row['password']) {
        $_SESSION['login_error'] = "Incorrect password!";
        header("Location: login.php");
        exit();
    }

    if ($remember) {
        setcookie("userID", $row['userID'], time() + (3600 * 24 * 7), "/");
    }

    $_SESSION['user_id'] = $row['userID'];
    $_SESSION['login_user'] = $row['username'];
    $_SESSION['login_email'] = $row['email'];
    $_SESSION['current_role'] = $row['role'];

    if ($row['role'] == 'admin') {
        header("Location: ../admin-page/dashboard.php");
        exit();
    } else {
        header("location: ../Member_page/Home-quest.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Furniland - Login</title>
    <link rel="stylesheet" href="../assets/css/memberpage/login.css" />
    <style>
        .error-msg {
            color: red;
            font-size: 14px;
            text-align: center;
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>
  <main>
      <div class="form-wrapper">
          <h1 class="form-title">Login</h1>

          <form id="login-form" action="" method="post">
              <div class="input-container">
                <label for="login-email">Email</label>
                <input type="text" id="login-email" name="email" />
              </div>

              <div class="input-container">
                <label for="login-password">Password</label>
                <input type="password" id="login-password" name="password"/>
              </div>

              <div class="check-area">
                <input type="checkbox" id="login-remember" name="remember"/>
                <label for="login-remember">Remember me</label>
              </div>

              <span id="login-error" class="error-msg">
                  <?php
                  if (isset($_SESSION['login_error'])){
                      echo $_SESSION['login_error'];
                      unset($_SESSION['login_error']);
                  }
                  ?>
              </span>

              <button type="submit" class="btn"  id="btn" name="login">Login</button>
              <span id="text-under-btn">Don't have an account?<a href="../Member_page/register.php" id="link-register">Register Here</a></span>
          </form>
      </div>
  </main>
    <script src="../assets/login.js"></script>

<?php
include ('../index/footer.php');
?>

</body>
</html>