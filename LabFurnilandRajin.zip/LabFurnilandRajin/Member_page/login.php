<?php
include ('../index/index.php');   

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {

    $email = $_POST['email'];
    $password = $_POST['password'];
    $remember = isset($_POST['remember']); 

    if (empty($email) || empty($password)) {
        $_SESSION['login_error'] = "Email and password must not be empty!";
        header("Location: login.php");
        exit();
    }

    $check_query = "SELECT * FROM users WHERE email='$email'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) != 1) {
        $_SESSION['login_error'] = "Email not found!";
        header("Location: login.php");
        exit();
    }

    $row = mysqli_fetch_assoc($check_result);

    if ($password !== $row['password']) {
        $_SESSION['login_error'] = "Incorrect password!";
        header("Location: login.php");
        exit();
    }

    if ($remember) {
    setcookie("userId", $row['userId'], time() + (3600 * 24 * 7), "/");
    }
    $_SESSION['login_user']   = $row['username'];
    $_SESSION['login_email']  = $row['email'];
    $_SESSION['current_role'] = $row['role'];


    header("Location:Home-quest.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Furniland - Login</title>
  <link rel="stylesheet" href="../assets/css/login.css" />
</head>
<body>
  <nav id="nav-container">
    <div id="nav-logo">
      <a href="../Member_page/Home-quest.php" id="Furniland">Furniland</a>
      <a href="../Member_page/Home-quest.php" id="Home">Home</a>
    </div>
    <div id="menu">
      <a href="../Member_page/login.php" id="Login">Login</a>
    </div>
  </nav>

  <main>
    <div class="form-wrapper">
      <h1 class="form-title">Login</h1>
      <form id="login-form" action="" method="post">
        <div class="input-container">
          <label for="login-email">Email</label>
          <input type="text" id="login-email" name="email" />
        </div>

        <div class="input-container">
          <label for="login-password">Password</label>
          <input type="password" id="login-password" name="password"/>
        </div>

        <div class="check-area">
          <input type="checkbox" id="login-remember" name="remember"/>
          <label for="login-remember">Remember me</label>
        </div>
        <span id="login-error" class="error-msg"></span>
        <button type="submit" class="btn"  id="btn" name="login">
          Login
        </button> 
        <span id="text-under-btn">Don't have an account?<a href="../Member_page/register.php" id="link-register">Register Here</a></span>
      </form>
    </div>
  </main>

  <footer>
    <span class="footer-top">@2025 Furniland All right reserved <br>Contact us at </span><span class="footer-bot">furniland.support@gmail.com</span></br>
  </footer>

  <script src="../assets/login.js"></script>

</body>
</html>
