<?php 
include ('../index/index.php');  
include ('../index/navbar.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Furniland - Home</title>
  <link rel="stylesheet" href="../assets/css/Home-quest.css" />
</head>
<body>

  <main>
      <div id="top-section">
        <h1 class="hero-text">Furniland</h1>
        <span class="section-title">Furnitures you might like</span>
      </div>

    <section>
      <div class="product-grid">
          <div class="product-card">
            <img src="img/kursiputih.jpeg" alt="Product Image" />
              <div class="text-area">
              <div class="product-name">Felix Accent Armchair</div>
              <div class="product-desc">Mid-Century armchaie with soft velvet fabric and gold metal legs.</div>
              <div class="product-price">Rp 1.950.000</div>
                <button class="product-actions">
                <a href="product-detail.html" class="detail">View Detail</a>
                </button>
            </div>
          </div>

        <div class="product-card">
          <img src="img/kursikeluarga.jpeg" alt="Product Image" />
          <div class="text-area">
            <div class="product-name">Kyra Dining Set(4 Chairs)</div>
            <div class="product-desc">Stylish wood table with cushioned chairs, perfect for modern homes.</div>
            <div class="product-price">Rp 3.790.000</div>
                <button class="product-actions">
                <a href="product-detail.html" class="detail">View Detail</a>
                </button>
          </div>
        </div>

        <div class="product-card">
          <img src="img/rakdinding.jpeg" alt="Product Image" />
          <div class="text-area">
            <div class="product-name">Zeno Floating Wall Shelf</div>
            <div class="product-desc">Wall-mounted shelf made of engineered wood and easy to install.</div>
            <div class="product-price">Rp 499.000</div>
                <button class="product-actions">
                <a href="product-detail.html" class="detail">View Detail</a>
                </button>
          </div>
        </div>

        <div class="product-card">
          <img src="img/pot.jpeg" alt="Product Image" />
          <div class="text-area">
            <div class="product-name">Chae's Study Table + Drawer</div>
            <div class="product-desc">Study desk with twice side drawer unit and smooth oak finish.</div>
            <div class="product-price">Rp 1.675.000</div>
                <button class="product-actions">
                <a href="product-detail.html" class="detail">View Detail</a>
                </button>
          </div>
        </div>

        <div class="product-card">
          <img src="img/potkedua.avif" alt="Product Image" />
            <div class="text-area">
            <div class="product-name">Verra Minimalist Coffee Table</div>
            <div class="product-desc">Round table with tempered glass top and matte black steel frame.</div>
            <div class="product-price">Rp 1.150.000</div>
                <button class="product-actions">
                <a href="product-detail.html" class="detail">View Detail</a>
                </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>


  <footer>
    <span class="footer-top">@2025 Furniland All right reserved <br>Contact us at </span><span class="footer-bot">furniland.support@gmail.com</span></br>
  </footer>


  <script src="assets/js/main.js"></script>
</body>
</html>

