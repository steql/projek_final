<?php
include ('../index/index.php');
include ('../index/navbar.php');


$product_query = "SELECT productID, productName, description, price, image FROM products ORDER BY productID DESC LIMIT 5";
$product_result = mysqli_query($conn, $product_query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Furniland - Home</title>
    <link rel="stylesheet" href="../assets/css/memberpage/Home-quest.css" />
</head>
<body>
  <main>
      <div id="top-section">
        <h1 class="hero-text">Furniland</h1>
        <span class="section-title">Furnitures you might like</span>
      </div>

    <section>
      <div class="product-grid">
        <?php
          if (mysqli_num_rows($product_result) > 0) {
            while ($row = mysqli_fetch_assoc($product_result)) {
              $productID = htmlspecialchars($row['productID']);
              $name = htmlspecialchars($row['productName']);
              $desc = htmlspecialchars($row['description']);
              $price = number_format($row['price'], 0, ',', '.');
              $image = htmlspecialchars($row['image']);
        ?>
          <div class="product-card">
            <img src="<?= $image ?>" alt="<?= $name ?>" />
            <div class="text-area">
              <div class="product-name"><?= $name ?></div>
              <div class="product-desc"><?= $desc ?></div>
              <div class="product-price">Rp <?= $price ?></div>
              <button class="product-actions">
                <a href="productdetail.php?id=<?= $productID ?>" class="detail">View Detail</a>
              </button>
            </div>
          </div>
            <?php
                }
            } 
            ?>
          </div>
        </section>
    </main>


<?php
include ('../index/footer.php');
?>

</body>
</html>